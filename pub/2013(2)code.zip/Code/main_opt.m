%% Pose Estimation for General Camera Models Using Lines
%  P. Miraldo
%
%  Returns convergence ratio as a function of:
%    -> Deviation from Central Case;
%    -> Number of lines;
%    -> and number of points that constitute the image cuve
function convergence_rate = main_opt(data_type,num_lines,n_points_lines)

global Mp


NUM_POINTS = n_points_lines;
deph = 100;
NUMBER_TRIALS = 10^3; % 10^4

NUM_LINHAS = num_lines;
CAMERA_VAL = data_type;
NOISE_VAL = 0;

% Plot the results
PLOT_FLAG = 1;  % plot 3D lines
PLOT_INFO = 1;  % show errors

CONVERGE = 0;

for iter = 1 : NUMBER_TRIALS
    
    %% Data set
    
    % rotation and translation
    R1 = randn()*2*pi;
    R2 = randn()*2*pi;
    R3 = randn()*2*pi;
    
    R = angle2dcm( R1, R2, R3 );
    Max_T = 100;
    T = rand(3,1)*Max_T*2 - ones(3,1)*Max_T;
    sT = [0 -T(3) T(2); T(3) 0 -T(1); -T(2) T(1) 0];
    E = [R zeros(3,3); -sT*R R];
    
    Rgt = R; Tgt = T;
    
    % 3D lines for both world and camera coordinate system
    PluCorL = zeros(6,NUM_LINHAS);
    PuL     = zeros(3,NUM_LINHAS);
    PluCorW = zeros(6,NUM_LINHAS);
    for i = 1 : NUM_LINHAS
        du_ = randn(3,1);
        du_ = du_ / norm(du_);
        pu_ = rand(3,1)*deph*2 - ones(3,1)*deph;
        PluCorL(:,i) = [du_;cross(pu_,du_)];
        PuL(:,i) = pu_;
        
        PluCorW(:,i) = E*PluCorL(:,i);
    end
    
    % projection lines
    DC = zeros(3,NUM_POINTS,NUM_LINHAS);
    PC = zeros(3,NUM_POINTS,NUM_LINHAS);
    
    PL  = zeros(6,NUM_POINTS,NUM_LINHAS);
    
    for j = 1 : NUM_LINHAS
        
        du = PluCorL(1:3,j);
        pu = PuL(:,j);
        
        l = rand(NUM_POINTS,1)*deph*2 - ones(NUM_POINTS,1)*deph;
        
        for i = 1 : NUM_POINTS
            
            daux_ = randn(3,1);
            daux_ = daux_/norm(daux_);
            daux_ = daux_*randn(1,1)*NOISE_VAL;
            
            p_ = pu + l(i)*du + daux_;
            
            p2_ = rand(3,1)*CAMERA_VAL*2 - ones(3,1)*CAMERA_VAL - [0;0;400];
            d_ = p_ - p2_;
            d_ = d_/ norm(d_);
            DC(:,i,j) = d_;
            
            PC(:,i,j) = p_;
            PL(:,i,j) = [d_; cross(p_,d_)];
            
        end

    end
    
    %% Non-linear optimization
    Mp = zeros(NUM_POINTS*NUM_LINHAS,18);
    m = 1;
    for j = 1 : NUM_LINHAS
        for i = 1 : NUM_POINTS
            
            lC1 = PL(1,i,j); lC2 = PL(2,i,j); lC3 = PL(3,i,j);
            lC4 = PL(4,i,j); lC5 = PL(5,i,j); lC6 = PL(6,i,j);
            
            lW1 = PluCorW(1,j); lW2 = PluCorW(2,j); lW3 = PluCorW(3,j);
            lW4 = PluCorW(4,j); lW5 = PluCorW(5,j); lW6 = PluCorW(6,j);
            
            Mp(m,:) = [  lC1*lW4 + lC4*lW1, lC2*lW4 + lC5*lW1, lC3*lW4 + lC6*lW1, ...
                lC1*lW5 + lC4*lW2, lC2*lW5 + lC5*lW2, lC3*lW5 + lC6*lW2, ...
                lC1*lW6 + lC4*lW3, lC2*lW6 + lC5*lW3, lC3*lW6 + lC6*lW3, ...
                -lC1*lW1, -lC2*lW1, -lC3*lW1, -lC1*lW2, -lC2*lW2, -lC3*lW2, ...
                -lC1*lW3, -lC2*lW3, -lC3*lW3];
            
            m = m + 1;
            
        end
    end
    
    
    t0 = zeros(3,1);
    r1 = randn()*2*pi; r2 = randn()*2*pi; r3 = randn()*2*pi;
    R0 = angle2dcm(r1,r2,r3);
    
    E0  = [0 , -t0(3) , t0(2) ; t0(3) , 0 , -t0(1) ; -t0(2) , t0(1) , 0]*R0;
    R0t = R0(:); E0t = E0(:);
    vt = [R0t;E0t];
    
    
    [x,~,~] =  fmincon(@f,vt,[],[],[],[],[],[],@nonlincon,optimset('display','off','algorithm','sqp'));
    
    r1 = x(1); r4 = x(4); r7 = x(7); r2 = x(2); r5 = x(5); r8 = x(8); r3 = x(3); r6 = x(6); r9 = x(9);
    e1 = x(10); e4 = x(13); e7 = x(16); e2 = x(11); e5 = x(14); e8 = x(17); e3 = x(12); e6 = x(15); e9 = x(18);
    
    Ri = [r1 r4 r7; r2 r5 r8; r3 r6 r9];
    sti = [e1 e4 e7; e2 e5 e8; e3 e6 e9]*Ri';
    ti = [-sti(2,3)+sti(3,2);sti(1,3)-sti(3,1);-sti(1,2)+sti(2,1)]/2;
    [ai,bi,ci] = dcm2angle(Ri);
    
    %% Results
    
    [agt,bgt,cgt] = dcm2angle(Rgt');
    ttgt = -Rgt'*Tgt;
    
    if PLOT_INFO == 1
        disp('Results...')
        disp('Results for rotation')
        disp(['Ground Truth       : (yaw, pitch, roll): (', num2str(agt),',',num2str(bgt),',',num2str(cgt),')'])
        disp(['Optimization       : (yaw, pitch, roll): (', num2str(ai),',',num2str(bi),',',num2str(ci),')'])
        
        disp('Results for translation')
        disp(['Ground Truth       : (tx, ty, tz): (', num2str(ttgt(1)),',',num2str(ttgt(2)),',',num2str(ttgt(3)),')'])
        disp(['Optimization       : (tx, ty, tz): (', num2str(ti(1)),',',num2str(ti(2)),',',num2str(ti(3)),')'])
        
    end
    
    err5 = abs(agt-ai); err6 = abs(bgt-bi);
    err7 = abs(cgt-ci); err8 = norm([agt;bgt;cgt]-[ai;bi;ci]);
    
    verr = [err5;err6;err7;err8];
    nerr = norm(verr);
    
    if nerr < 10^(-5)
        CONVERGE = CONVERGE+1;
    end
    
    %% plot data
    if PLOT_FLAG == 1
        
        figure(1);
        clf
        hold on
        
        for j = 1 : NUM_LINHAS
            
            du = PluCorL(1:3,j);
            pu = PuL(:,j);
            
            deph2 = deph*5;
            lu_  = pu + deph2*du;
            lu__ = pu - deph2*du;
            plot3([lu_(1) lu__(1)], [lu_(2) lu__(2)], [lu_(3) lu__(3)],'Color', 'r', 'LineWidth', 4)
            
            for i = 1 : NUM_POINTS
                deph2 = deph*5;
                lu_  = PC(:,i,j) + deph2*DC(:,i,j);
                lu__ = PC(:,i,j) - deph2*DC(:,i,j);
                plot3([lu_(1) lu__(1)], [lu_(2) lu__(2)], [lu_(3) lu__(3)],'Color', 'b', 'LineWidth', 2)
                
                plot3(PC(1,:),PC(2,:),PC(3,:),'o','MarkerSize',7,'Color','g','LineWidth',6)
            end
            
        end
        
        grid on
        view(-60,20)
        axis tight
        P = get(gca,'Position');
        P(4) = 3/4*P(3);
        set(gca,'Position',P);
        set(gca,'FontSize',15);
        hold off
        pause
    end
    
end


disp(['Convergence Rate: ', num2str(100*CONVERGE/NUMBER_TRIALS),'%'])
convergence_rate = 100*CONVERGE/NUMBER_TRIALS;


end

% objective functions
function y = f(x)
global Mp
y = (x')*(Mp')*Mp*x;
end


% Nonlinear constraints function
function [c, ceq] = nonlincon(x)

c = [];

r1 = x(1); r4 = x(4); r7 = x(7);
r2 = x(2); r5 = x(5); r8 = x(8);
r3 = x(3); r6 = x(6); r9 = x(9);

e1 = x(10); e4 = x(13); e7 = x(16);
e2 = x(11); e5 = x(14); e8 = x(17);
e3 = x(12); e6 = x(15); e9 = x(18);

c1 = r1^2 + r2^2 + r3^2-1;
c2 = r1*r4 + r2*r5 + r3*r6;
c3 = r1*r7 + r2*r8 + r3*r9;
c4 = r1*r4 + r2*r5 + r3*r6;
c5 = r4^2 + r5^2 + r6^2-1;
c6 = r4*r7 + r5*r8 + r6*r9;
c7 = r1*r7 + r2*r8 + r3*r9;
c8 = r4*r7 + r5*r8 + r6*r9;
c9 = r7^2 + r8^2 + r9^2-1;
c10 = e1*r1 + e4*r4 + e7*r7;
c11 = e2*r2 + e5*r5 + e8*r8;
c12 = e3*r3 + e6*r6 + e9*r9;
c13 = e1*r2 + e2*r1 + e4*r5 + e5*r4 + e7*r8 + e8*r7;
c14 = e1*r3 + e3*r1 + e4*r6 + e6*r4 + e7*r9 + e9*r7;
c15 = e2*r3 + e3*r2 + e5*r6 + e6*r5 + e8*r9 + e9*r8;

ceq = [c1 c2 c3 c4 c5 c6 c7 c8 c9 c10 c11 c12 c13 c14 c15]';

end
