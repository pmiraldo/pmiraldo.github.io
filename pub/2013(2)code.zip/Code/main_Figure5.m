%% Pose Estimation for General Camera Models Using Lines
%  Author: Pedro Daniel dos Santos Miraldo
%  Institution: Institute for Systens and Robotics, University of Coimbra
%  Evaluation - Figure 5
clear all
close all
clc

NUM_LINES = 1:1:20;
CAM_MODEL = [800;100;50;20;0];
CONVERGENVE_ARRAY = zeros(numel(CAM_MODEL),numel(NUM_LINES));

tic
for iiter = 1 : numel(CAM_MODEL)
    for iter = 1 : numel(NUM_LINES)
        disp(['Camera Model: ',num2str(iiter)])
        disp(['Number of Lines: ',num2str(iter)])
        CONVERGENVE_ARRAY(iiter,iter) = main_opt(CAM_MODEL(iiter),NUM_LINES(iter),40);
    end
end
toc

close all

color_b  = [0.3,0.3,0.8]; color_r  = [0.9,0.2,0.2]; color_g  = [0.3,0.8,0.3];
color_br = [139,69,19]/256; color_v  = [153,50,204]/256;

figure(1)
hold on
h(1) = plot(NUM_LINES,CONVERGENVE_ARRAY(1,:),'-','Color',color_b,'LineWidth',4);
h(2) = plot(NUM_LINES,CONVERGENVE_ARRAY(2,:),'-','Color',color_r,'LineWidth',4);
h(3) = plot(NUM_LINES,CONVERGENVE_ARRAY(3,:),'-','Color',color_g,'LineWidth',4);
h(4) = plot(NUM_LINES,CONVERGENVE_ARRAY(4,:),'-','Color',color_v,'LineWidth',4);
h(5) = plot(NUM_LINES,CONVERGENVE_ARRAY(5,:),'-','Color',color_br,'LineWidth',4);
hold off
hlegend = legend([h(1),h(2),h(3),h(4),h(5)],'General Case', 'Deviation from Central Case = 100',...
'Deviation from Central Case = 50', 'Deviation from Central Case = 10', ...
'Central Camera - Deviation from Central Case = 0',4);
set(hlegend,'FontSize',14)
axis([NUM_LINES(1) NUM_LINES(numel(NUM_LINES)) 0 100])
xlabel('Number of 3D Straight Lines','FontSize',20)
title('Convergence Ratio','FontSize',20)
P = get(gca,'Position');
P(4) = 3/4*P(4);
set(gca,'Position',P);
set(gca,'Box','on');
saveas(gca,'./Figure_Gen_Conv.eps','epsc')

save('data_convergence_general')
