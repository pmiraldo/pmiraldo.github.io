%% Pose Estimation for General Camera Models Using Lines
%  Author: Pedro Daniel dos Santos Miraldo
%  Institution: Institute for Systens and Robotics, University of Coimbra
%  Evaluation - Figure 4
function main_Figure4()

clear all
close all
clc

data_type = input('Subfigure reference [a, b, c, d]: ','s');
if ~(data_type == 'a' || data_type == 'b' || data_type == 'c' || data_type == 'd')
    disp('ERROR: non-valid option');
    return;
end

global Mp


%% configurations

NUM_xGRAPH = 80;
NUM_POINTS = 40;
deph = 100;
NUMBER_TRIALS = 1000;

switch data_type
    case 'a'
        NOISE_ARRAY        = linspace(0.1,10,NUM_xGRAPH);
        NUM_LINES_ARRAY    = ones(1,NUM_xGRAPH)*10;
        CAMERA_MODEL_ARRAY = ones(1,NUM_xGRAPH)*800;
        ROTATION_FIG       = 'Figure_3a1.eps';
        TRANSLATION_FIG    = 'Figure_3a2.eps';
        XLEGEND            = 'Noise';
        XARRAY             = NOISE_ARRAY;
        DATA_WORKSPACE     = 'data_random_data_noise.mat';
    case 'b'
        NUM_xGRAPH         = 13;
        NOISE_ARRAY        = ones(1,NUM_xGRAPH)*20;
        NUM_LINES_ARRAY    = linspace(3,15,NUM_xGRAPH);
        CAMERA_MODEL_ARRAY = ones(1,NUM_xGRAPH)*800;
        ROTATION_FIG       = 'Figure_3b1.eps';
        TRANSLATION_FIG    = 'Figure_3b2.eps';
        XLEGEND            = 'Number of Lines';
        XARRAY             = NUM_LINES_ARRAY;
        DATA_WORKSPACE     = 'data_random_data_numlines.mat';
    case 'c'
        NOISE_ARRAY        = linspace(0.1,10,NUM_xGRAPH);
        NUM_LINES_ARRAY    = ones(1,NUM_xGRAPH)*10;
        CAMERA_MODEL_ARRAY = ones(1,NUM_xGRAPH)*10;
        ROTATION_FIG       = 'Figure_3c1.eps';
        TRANSLATION_FIG    = 'Figure_3c2.eps';
        XLEGEND            = 'Noise';
        XARRAY             = NOISE_ARRAY;
        DATA_WORKSPACE     = 'data_closecentral_data_noise.mat';
    case 'd'
        NOISE_ARRAY        = ones(1,NUM_xGRAPH)*10;
        NUM_LINES_ARRAY    = ones(1,NUM_xGRAPH)*10;
        CAMERA_MODEL_ARRAY = linspace(40,5,NUM_xGRAPH);
        ROTATION_FIG       = 'Figure_3d1.eps';
        TRANSLATION_FIG    = 'Figure_3d2.eps';
        XLEGEND            = 'Distance from Central Case';
        XARRAY             = CAMERA_MODEL_ARRAY*2;
        DATA_WORKSPACE     = 'data_closecentral_variation_data.mat';        
end


disp(['Noise array     min: ', num2str(NOISE_ARRAY(1)),' max: ', num2str(NOISE_ARRAY(numel(NOISE_ARRAY)))]);
disp(['Num Lines array min: ', num2str(NUM_LINES_ARRAY(1)),' max: ', num2str(NUM_LINES_ARRAY(numel(NUM_LINES_ARRAY)))]);
disp(['Camera Array    min: ', num2str(CAMERA_MODEL_ARRAY(1)),' max: ', num2str(CAMERA_MODEL_ARRAY(numel(CAMERA_MODEL_ARRAY)))]);

RESULTS_ROTATION    = zeros(8,NUM_xGRAPH);
RESULTS_TRANSLATION = zeros(8,NUM_xGRAPH);

disp(['Number of image points for each 3D lines: ', num2str(NUM_POINTS)]);
disp(['Number of trials: ', num2str(NUMBER_TRIALS)]);
disp(['Number of iterations: ', num2str(NUM_xGRAPH)]);

%% Plot configuratoins
PLOT_FLAG = 0; % plot 3d lines
PLOT_INFO = 0; % display errors

disp('Paused...')
pause
disp('Start...')
tic_all = tic;

%% Start
for iiter = 1 : NUM_xGRAPH
    
    disp(['iter: ', num2str(iiter)])
    
    RESULTS_ROTATION_ITER    = zeros(8,NUMBER_TRIALS);
    RESULTS_TRANSLATION_ITER = zeros(8,NUMBER_TRIALS);
    
    NUM_LINHAS = NUM_LINES_ARRAY(iiter);
    NOISE_VAL  = NOISE_ARRAY(iiter);
    CAMERA_VAL = CAMERA_MODEL_ARRAY(iiter);

    for iter = 1 : NUMBER_TRIALS
        
        % Data-set: rotation and translation
        R1 = randn()*2*pi;
        R2 = randn()*2*pi;
        R3 = randn()*2*pi;
        
        R = angle2dcm( R1, R2, R3 );
        Max_T = 100;
        T = rand(3,1)*Max_T*2 - ones(3,1)*Max_T;
        sT = [0 -T(3) T(2); T(3) 0 -T(1); -T(2) T(1) 0];
        E = [R zeros(3,3); -sT*R R];
        
        Rgt = R; Tgt = T;
        
        % Data-set: 3D lines in both world and camera coordinates
        PluCorL = zeros(6,NUM_LINHAS);
        PuL     = zeros(3,NUM_LINHAS);
        PluCorW = zeros(6,NUM_LINHAS);
        for i = 1 : NUM_LINHAS
            du_ = randn(3,1);
            du_ = du_ / norm(du_);
            pu_ = rand(3,1)*deph*2 - ones(3,1)*deph;
            PluCorL(:,i) = [du_;cross(pu_,du_)];
            PuL(:,i) = pu_;
            
            PluCorW(:,i) = E*PluCorL(:,i);
        end
        
        % Data-set: projection lines
        DC = zeros(3,NUM_POINTS,NUM_LINHAS);
        PC = zeros(3,NUM_POINTS,NUM_LINHAS);
        
        PL  = zeros(6,NUM_POINTS,NUM_LINHAS);
        
        for j = 1 : NUM_LINHAS
            
            du = PluCorL(1:3,j);
            pu = PuL(:,j);
            
            l = rand(NUM_POINTS,1)*deph*2 - ones(NUM_POINTS,1)*deph;
            
            for i = 1 : NUM_POINTS
                
                daux_ = randn(3,1);
                daux_ = daux_/norm(daux_);
                daux_ = daux_*randn(1,1)*NOISE_VAL;
                                
                p_ = pu + l(i)*du + daux_;
                
                p2_ = rand(3,1)*CAMERA_VAL*2 - ones(3,1)*CAMERA_VAL - [0;0;0];
                d_ = p_ - p2_;
                d_ = d_/ norm(d_);
                DC(:,i,j) = d_;
                
                PC(:,i,j) = p_;
                PL(:,i,j) = [d_; cross(p_,d_)];
                
            end
        end
        
        % Analytical solution
        estimated_lines = zeros(NUM_LINHAS,6);
        for j = 1 : NUM_LINHAS
            
            Mp2 = zeros(NUM_POINTS,6);
            
            for i = 1 : NUM_POINTS
                
                ppl = PL(:,i,j);
                
                lC1 = ppl(1); lC2 = ppl(2); lC3 = ppl(3);
                lC4 = ppl(4); lC5 = ppl(5); lC6 = ppl(6);
                Mp2(i,:) = [lC1 lC2 lC3 lC4 lC5 lC6];
                
            end
            
            [v2,~] = eig(balance(Mp2'*Mp2));
            vii = v2(:,1);

            pij = [vii(4:6);vii(1:3)]'/norm(vii(4:6));
            pij = pij';
            estimated_lines(j,:) = pij;
        end
        
        A = estimated_lines(:,1:3); B  = PluCorW(1:3,:)';
        Sa = A'*B;
        
        [v2,~,v1] = svd(Sa);
        vvv1 = v2(:,1); vvv2 = v2(:,2); vvv3 = v2(:,3);
        
        V1 = [vvv1,vvv2,vvv3];
        V2 = [-vvv1,vvv2,vvv3];
        V3 = [vvv1,-vvv2,vvv3];
        V5 = [-vvv1,-vvv2,vvv3];
        
        if det(V1)*det(v1) > 0, R1 = V1*v1'; else R1 = V1*[1 0 0 ; 0 1 0 ; 0 0 -1]*v1'; end
        if det(V2)*det(v1) > 0, R2 = V2*v1'; else R2 = V2*[1 0 0 ; 0 1 0 ; 0 0 -1]*v1'; end
        if det(V3)*det(v1) > 0, R3 = V3*v1'; else R3 = V3*[1 0 0 ; 0 1 0 ; 0 0 -1]*v1'; end
        if det(V5)*det(v1) > 0, R5 = V5*v1'; else R5 = V5*[1 0 0 ; 0 1 0 ; 0 0 -1]*v1'; end
        
        res = zeros(4,1);
        for i = 1 : numel(B(:,1))
            b_ = B(i,:);
            a_ = A(i,:);
            res(1) = res(1) + norm(cross(b_,a_*R1));
            res(2) = res(2) + norm(cross(b_,a_*R2));
            res(3) = res(3) + norm(cross(b_,a_*R3));
            res(4) = res(4) + norm(cross(b_,a_*R5));
        end
        
        [~,I] = min(res);
                
        switch I, case 1, R0 = R1; case 2, R0 = R2; case 3, R0 = R3; case 4, R0 = R5; end
        
        r1 = R0(1,1); r4 = R0(1,2); r7 = R0(1,3);
        r2 = R0(2,1); r5 = R0(2,2); r8 = R0(2,3);
        r3 = R0(3,1); r6 = R0(3,2); r9 = R0(3,3);
        
        Mt = zeros(NUM_LINHAS*4,4);
        j = 1;
        for i = 1 : NUM_LINHAS
            
            li = estimated_lines(i,:)';
            lC4 = li(4); lC5 = li(5); lC6 = li(6);
            
            lii = PluCorW(:,i);
            
            lW1 = lii(1); lW2 = lii(2); lW3 = lii(3);
            lW4 = lii(4); lW5 = lii(5); lW6 = lii(6);
            
            tt1 = [ lC5*(lW1*r2 + lW2*r5 + lW3*r8) + lC6*(lW1*r3 + lW2*r6 + lW3*r9), ...
                    -lC5*(lW1*r1 + lW2*r4 + lW3*r7),...
                    -lC6*(lW1*r1 + lW2*r4 + lW3*r7), ...
                    lC6*(lW4*r2 + lW5*r5 + lW6*r8) - lC5*(lW4*r3 + lW5*r6 + lW6*r9)];
            tt2 = [ -lC4*(lW1*r2 + lW2*r5 + lW3*r8), ...
                    lC4*(lW1*r1 + lW2*r4 + lW3*r7) + lC6*(lW1*r3 + lW2*r6 + lW3*r9), ...
                    -lC6*(lW1*r2 + lW2*r5 + lW3*r8), ...
                    lC4*(lW4*r3 + lW5*r6 + lW6*r9) - lC6*(lW4*r1 + lW5*r4 + lW6*r7)];
            tt3 = [ -lC4*(lW1*r3 + lW2*r6 + lW3*r9), ...
                    -lC5*(lW1*r3 + lW2*r6 + lW3*r9),...
                    lC4*(lW1*r1 + lW2*r4 + lW3*r7) + lC5*(lW1*r2 + lW2*r5 + lW3*r8),...
                    lC5*(lW4*r1 + lW5*r4 + lW6*r7) - lC4*(lW4*r2 + lW5*r5 + lW6*r8)];
            tt4 = [ lC2*lW1*r3 - lC3*lW1*r2 + lC2*lW2*r6 - lC3*lW2*r5 + lC2*lW3*r9 - lC3*lW3*r8,...
                    lC3*lW1*r1 - lC1*lW1*r3 - lC1*lW2*r6 + lC3*lW2*r4 - lC1*lW3*r9 + lC3*lW3*r7,...
                    lC1*lW1*r2 - lC2*lW1*r1 + lC1*lW2*r5 - lC2*lW2*r4 + lC1*lW3*r8 - lC2*lW3*r7,...
                    lC1*lW4*r1 + lC4*lW1*r1 + lC2*lW4*r2 + lC5*lW1*r2 + lC1*lW5*r4 + lC3*lW4*r3 + lC4*lW2*r4 + lC6*lW1*r3 + lC2*lW5*r5 + lC5*lW2*r5 + lC1*lW6*r7 + lC3*lW5*r6 + lC4*lW3*r7 + lC6*lW2*r6 + lC2*lW6*r8 + lC5*lW3*r8 + lC3*lW6*r9 + lC6*lW3*r9];
            
            Mt(j,:)   = tt1; Mt(j+1,:) = tt2; Mt(j+2,:) = tt3; Mt(j+3,:) = tt4;
            j = j + 4;
        end
        
        Mt_ = Mt(:,1:3);
        Mt__ = -Mt(:,4);
        t0 = pinv(Mt_)*Mt__;
        
        
        % Non-linear optimization
        Mp = zeros(NUM_POINTS*NUM_LINHAS,18);
        m = 1;
        for j = 1 : NUM_LINHAS
            for i = 1 : NUM_POINTS
                
                lC1 = PL(1,i,j); lC2 = PL(2,i,j); lC3 = PL(3,i,j);
                lC4 = PL(4,i,j); lC5 = PL(5,i,j); lC6 = PL(6,i,j);
                
                lW1 = PluCorW(1,j); lW2 = PluCorW(2,j); lW3 = PluCorW(3,j);
                lW4 = PluCorW(4,j); lW5 = PluCorW(5,j); lW6 = PluCorW(6,j);
                
                Mp(m,:) = [  lC1*lW4 + lC4*lW1, lC2*lW4 + lC5*lW1, lC3*lW4 + lC6*lW1, ...
                    lC1*lW5 + lC4*lW2, lC2*lW5 + lC5*lW2, lC3*lW5 + lC6*lW2, ...
                    lC1*lW6 + lC4*lW3, lC2*lW6 + lC5*lW3, lC3*lW6 + lC6*lW3, ...
                    -lC1*lW1, -lC2*lW1, -lC3*lW1, -lC1*lW2, -lC2*lW2, -lC3*lW2, ...
                    -lC1*lW3, -lC2*lW3, -lC3*lW3];
                
                m = m + 1;
                
            end
        end

        
        E0  = [0 , -t0(3) , t0(2) ; t0(3) , 0 , -t0(1) ; -t0(2) , t0(1) , 0]*R0;
        R0t = R0(:); E0t = E0(:);
        vt = [R0t;E0t];

        [x,~,~] =  fmincon(@f,vt,[],[],[],[],[],[],@nonlincon,optimset('display','off','algorithm','sqp'));
        
        r1 = x(1); r4 = x(4); r7 = x(7); r2 = x(2); r5 = x(5); r8 = x(8); r3 = x(3); r6 = x(6); r9 = x(9);
        e1 = x(10); e4 = x(13); e7 = x(16); e2 = x(11); e5 = x(14); e8 = x(17); e3 = x(12); e6 = x(15); e9 = x(18); 
        
        Ri = [r1 r4 r7; r2 r5 r8; r3 r6 r9];
        sti = [e1 e4 e7; e2 e5 e8; e3 e6 e9]*Ri';
        ti = [-sti(2,3)+sti(3,2);sti(1,3)-sti(3,1);-sti(1,2)+sti(2,1)]/2;
        [ai,bi,ci] = dcm2angle(Ri);

        % Results

        [a0 ,b0 ,c0 ] = dcm2angle(R0);
        [agt,bgt,cgt] = dcm2angle(Rgt');
        ttgt = -Rgt'*Tgt;

        if PLOT_INFO == 1
            disp('Results...')
            disp('Results for rotation')
            disp(['Ground Truth       : (yaw, pitch, roll): (', num2str(agt),',',num2str(bgt),',',num2str(cgt),')'])
            disp(['Initial Estimation : (yaw, pitch, roll): (', num2str(a0),',',num2str(b0),',',num2str(c0),')'])
            disp(['Optimization       : (yaw, pitch, roll): (', num2str(ai),',',num2str(bi),',',num2str(ci),')'])
            
            disp('Results for translation')
            disp(['Ground Truth       : (tx, ty, tz): (', num2str(ttgt(1)),',',num2str(ttgt(2)),',',num2str(ttgt(3)),')'])
            disp(['Initial Estimation : (tx, ty, tz): (', num2str(t0(1)),',',num2str(t0(2)),',',num2str(t0(3)),')'])
            disp(['Optimization       : (tx, ty, tz): (', num2str(ti(1)),',',num2str(ti(2)),',',num2str(ti(3)),')'])

        end
        
        RESULTS_TRANSLATION_ITER(1,iter) = min([abs((ttgt(1)-t0(1)));abs((ttgt(1)-t0(1)))]);
        RESULTS_TRANSLATION_ITER(2,iter) = min([abs((ttgt(2)-t0(2)));abs((ttgt(2)-t0(2)))]);
        RESULTS_TRANSLATION_ITER(3,iter) = min([abs((ttgt(3)-t0(3)));abs((ttgt(3)-t0(3)))]);
        RESULTS_TRANSLATION_ITER(4,iter) = norm(ttgt-t0);
        RESULTS_TRANSLATION_ITER(5,iter) = min([abs((ttgt(1)-ti(1)));abs((ttgt(1)-ti(1)))]);
        RESULTS_TRANSLATION_ITER(6,iter) = min([abs((ttgt(2)-ti(2)));abs((ttgt(2)-ti(2)))]);
        RESULTS_TRANSLATION_ITER(7,iter) = min([abs((ttgt(3)+ti(3)));abs((ttgt(3)-ti(3)))]);
        RESULTS_TRANSLATION_ITER(8,iter) = norm(ttgt-ti);
        
        RESULTS_ROTATION_ITER(1,iter) = min([abs(agt+a0);abs(agt-a0)]);
        RESULTS_ROTATION_ITER(2,iter) = min([abs(bgt+b0);abs(bgt-b0)]);
        RESULTS_ROTATION_ITER(3,iter) = min([abs(cgt+c0);abs(cgt-c0)]);
        RESULTS_ROTATION_ITER(4,iter) = norm([agt;bgt;cgt]-[a0;b0;c0]);
        RESULTS_ROTATION_ITER(5,iter) = min([abs(agt-ai) abs(agt+ai)]);
        RESULTS_ROTATION_ITER(6,iter) = min([abs(bgt-bi) abs(bgt+bi)]);
        RESULTS_ROTATION_ITER(7,iter) = min([abs(cgt-ci) abs(cgt+ci)]);
        RESULTS_ROTATION_ITER(8,iter) = norm([agt;bgt;cgt]-[ai;bi;ci]);
        
        % plot data
        
        
        if PLOT_FLAG == 1
            
            figure(1);
            clf
            hold on
            
            for j = 1 : NUM_LINHAS
                
                du = PluCorL(1:3,j);
                pu = PuL(:,j);
                
                deph2 = deph*5;
                lu_  = pu + deph2*du;
                lu__ = pu - deph2*du;
                plot3([lu_(1) lu__(1)], [lu_(2) lu__(2)], [lu_(3) lu__(3)],'Color', 'r', 'LineWidth', 4)
                
                for i = 1 : NUM_POINTS
                    deph2 = deph*5;
                    lu_  = PC(:,i,j) + deph2*DC(:,i,j);
                    lu__ = PC(:,i,j) - deph2*DC(:,i,j);
                    plot3([lu_(1) lu__(1)], [lu_(2) lu__(2)], [lu_(3) lu__(3)],'Color', 'b', 'LineWidth', 2)
                    
                    plot3(PC(1,:),PC(2,:),PC(3,:),'o','MarkerSize',7,'Color','g','LineWidth',6)
                end
                
            end
            
            grid on
            view(-60,20)
            axis tight
            P = get(gca,'Position');
            P(4) = 3/4*P(3);
            set(gca,'Position',P);
            set(gca,'FontSize',15);
            saveas(gcf,'Figure_2.eps','epsc')
            hold off
            pause
            
        end
        
    end
    
    RESULTS_ROTATION(1,iiter)    = median(RESULTS_ROTATION_ITER(1,:));
    RESULTS_ROTATION(2,iiter)    = median(RESULTS_ROTATION_ITER(2,:));
    RESULTS_ROTATION(3,iiter)    = median(RESULTS_ROTATION_ITER(3,:));
    RESULTS_ROTATION(4,iiter)    = median(RESULTS_ROTATION_ITER(4,:));
    
    RESULTS_TRANSLATION(1,iiter) = median(RESULTS_TRANSLATION_ITER(1,:));
    RESULTS_TRANSLATION(2,iiter) = median(RESULTS_TRANSLATION_ITER(2,:));
    RESULTS_TRANSLATION(3,iiter) = median(RESULTS_TRANSLATION_ITER(3,:));
    RESULTS_TRANSLATION(4,iiter) = median(RESULTS_TRANSLATION_ITER(4,:));
    
    RESULTS_ROTATION(5,iiter)    = median(RESULTS_ROTATION_ITER(5,:));
    RESULTS_ROTATION(6,iiter)    = median(RESULTS_ROTATION_ITER(6,:));
    RESULTS_ROTATION(7,iiter)    = median(RESULTS_ROTATION_ITER(7,:));
    RESULTS_ROTATION(8,iiter)    = median(RESULTS_ROTATION_ITER(8,:));
    
    RESULTS_TRANSLATION(5,iiter) = median(RESULTS_TRANSLATION_ITER(5,:));
    RESULTS_TRANSLATION(6,iiter) = median(RESULTS_TRANSLATION_ITER(6,:));
    RESULTS_TRANSLATION(7,iiter) = median(RESULTS_TRANSLATION_ITER(7,:));
    RESULTS_TRANSLATION(8,iiter) = median(RESULTS_TRANSLATION_ITER(8,:));
    
end

toc(tic_all)
save(DATA_WORKSPACE)

r_color = [.75 .2 .2];
g_color = [.2 .75 .2];
b_color = [.2 .2 .75];

%% plot the results

close all
figure(1)
hold on
title('Median of the Rotation Error','FontSize',27)
if data_type ~= 'b'
    h1 = plot(XARRAY,RESULTS_ROTATION(1,:),'LineStyle','--','Color',r_color,'LineWidth',3);
    h2 = plot(XARRAY,RESULTS_ROTATION(2,:),'LineStyle','--','Color',g_color,'LineWidth',3);
    h3 = plot(XARRAY,RESULTS_ROTATION(3,:),'LineStyle','--','Color',b_color,'LineWidth',3);
    h5 = plot(XARRAY,RESULTS_ROTATION(5,:),'LineStyle','-','Color',r_color,'LineWidth',3);
    h6 = plot(XARRAY,RESULTS_ROTATION(6,:),'LineStyle','-','Color',g_color,'LineWidth',3);
    h7 = plot(XARRAY,RESULTS_ROTATION(7,:),'LineStyle','-','Color',b_color,'LineWidth',3);
    hlegend = legend([h1,h2,h3,h5,h6,h7],'Yaw - Analytical','Pitch - Analytical','Roll - Analytical','Yaw - Optimized','Pitch - Optimized','Roll - Optimized',2);
else
    h5 = plot(XARRAY,RESULTS_ROTATION(5,:),'o-','Color',r_color,'MarkerEdgeColor','k','MarkerFaceColor',r_color,'MarkerSize',10,'LineWidth',3);
    h6 = plot(XARRAY,RESULTS_ROTATION(6,:),'s-','Color',g_color,'MarkerEdgeColor','k','MarkerFaceColor',g_color,'MarkerSize',10,'LineWidth',3);
    h7 = plot(XARRAY,RESULTS_ROTATION(7,:),'V-','Color',b_color,'MarkerEdgeColor','k','MarkerFaceColor',b_color,'MarkerSize',10,'LineWidth',3);
    hlegend = legend([h5,h6,h7],'Yaw - Optimized','Pitch - Optimized','Roll - Optimized',2);
end

set(hlegend,'FontSize',20)
xlabel(XLEGEND,'FontSize',20)
set(gca,'Box','on');
axis tight
P = get(gca,'Position');
P(4) = 3/4*P(3);
set(gca,'Position',P);
set(gca,'FontSize',15);
if data_type == 'b' || data_type == 'd'
    set(gca,'xdir','reverse')
end
hold off
saveas(gcf,ROTATION_FIG,'epsc')

figure(2)
hold on
title('Median of the Translation Error','FontSize',27)
if data_type ~= 'b'
    h1 = plot(XARRAY,RESULTS_TRANSLATION(1,:),'LineStyle','--','Color',r_color,'LineWidth',3);
    h2 = plot(XARRAY,RESULTS_TRANSLATION(2,:),'LineStyle','--','Color',g_color,'LineWidth',3);
    h3 = plot(XARRAY,RESULTS_TRANSLATION(3,:),'LineStyle','--','Color',b_color,'LineWidth',3);
    h5 = plot(XARRAY,RESULTS_TRANSLATION(5,:),'LineStyle','-','Color',r_color,'LineWidth',3);
    h6 = plot(XARRAY,RESULTS_TRANSLATION(6,:),'LineStyle','-','Color',g_color,'LineWidth',3);
    h7 = plot(XARRAY,RESULTS_TRANSLATION(7,:),'LineStyle','-','Color',b_color,'LineWidth',3);
    hlegend = legend([h1,h2,h3,h5,h6,h7],'tx - Analytical','ty - Analytical','tz - Analytical','tx - Optimized','ty - Optimized','tz - Optimized',2);
else
    h5 = plot(XARRAY,RESULTS_TRANSLATION(5,:),'o-','Color',r_color,'MarkerEdgeColor','k','MarkerFaceColor',r_color,'MarkerSize',10,'LineWidth',3);
    h6 = plot(XARRAY,RESULTS_TRANSLATION(6,:),'s-','Color',g_color,'MarkerEdgeColor','k','MarkerFaceColor',g_color,'MarkerSize',10,'LineWidth',3);
    h7 = plot(XARRAY,RESULTS_TRANSLATION(7,:),'V-','Color',b_color,'MarkerEdgeColor','k','MarkerFaceColor',b_color,'MarkerSize',10,'LineWidth',3);
    hlegend = legend([h5,h6,h7],'tx - Optimized','ty - Optimized','tz - Optimized',2);
end

set(hlegend,'FontSize',20)
xlabel(XLEGEND,'FontSize',20)
set(gca,'Box','on')
axis tight
P = get(gca,'Position');
P(4) = 3/4*P(3);
set(gca,'Position',P);
set(gca,'FontSize',15);
if data_type == 'b' || data_type == 'd'
    set(gca,'xdir','reverse')
end
hold off
saveas(gcf,TRANSLATION_FIG,'epsc')

end

%% Non-linear optimization: objective functions
function y = f(x)
    global Mp
    y = (x')*(Mp')*Mp*x;
end


%% Non-linear optimization: nonlinear constraints function
function [c, ceq] = nonlincon(x)

c = [];

r1 = x(1); r4 = x(4); r7 = x(7);
r2 = x(2); r5 = x(5); r8 = x(8);
r3 = x(3); r6 = x(6); r9 = x(9);

e1 = x(10); e4 = x(13); e7 = x(16);
e2 = x(11); e5 = x(14); e8 = x(17);
e3 = x(12); e6 = x(15); e9 = x(18);

c1 = r1^2 + r2^2 + r3^2-1;
c2 = r1*r4 + r2*r5 + r3*r6;
c3 = r1*r7 + r2*r8 + r3*r9;
c4 = r1*r4 + r2*r5 + r3*r6;
c5 = r4^2 + r5^2 + r6^2-1;
c6 = r4*r7 + r5*r8 + r6*r9;
c7 = r1*r7 + r2*r8 + r3*r9;
c8 = r4*r7 + r5*r8 + r6*r9;
c9 = r7^2 + r8^2 + r9^2-1;
c10 = e1*r1 + e4*r4 + e7*r7;
c11 = e2*r2 + e5*r5 + e8*r8;
c12 = e3*r3 + e6*r6 + e9*r9;
c13 = e1*r2 + e2*r1 + e4*r5 + e5*r4 + e7*r8 + e8*r7;
c14 = e1*r3 + e3*r1 + e4*r6 + e6*r4 + e7*r9 + e9*r7;
c15 = e2*r3 + e3*r2 + e5*r6 + e6*r5 + e8*r9 + e9*r8;

ceq = [c1 c2 c3 c4 c5 c6 c7 c8 c9 c10 c11 c12 c13 c14 c15]';

end
