%% A Robust Parameterization for the General Minimal Pose Problem
% Author: Pedro Miraldo (miraldo@isr.uc.pt)
% Institution: Institute for Systems and Robotics, University of Coimbra
% Results Figure 2
clear all;
clc;

warning off; %#ok<WNOFF>

NumIter = 10^6;
PlotHyp = 0;
NAlgorithms = 6;
formatSpec = '%10e\n';
disp(['The number of iteration is: 10^', num2str(log10(NumIter))]);
disp('paused...'); pause;
disp('running...');

%% Variables for the results
numerical_errors_T = zeros(5, NumIter);
numerical_errors_R = zeros(5, NumIter);
numerical_errors_P = zeros(5, NumIter);

numerical_errors_N  = zeros(5, NumIter);
numerical_errors_NC = zeros(5, NumIter);

Computation_Time = zeros(5, NumIter);

TicTimeAll = tic;
iter = 0;
while iter < NumIter
    
    iter = iter + 1;
    
    %% Generate incident points
    dist = 200;
    PC = rand(3,3);
    PC = PC*[dist, 0, 0 ; 0, dist, 0 ; 0, 0, dist ];
    PC = PC - ones(size(PC))*[dist/2, 0, 0 ; 0, dist/2, 0 ; 0, 0, dist/2 ];
    
    %% Compute directions
    DC1 = randn(1,3); DC1 = DC1/norm(DC1);
    DC2 = randn(1,3); DC2 = DC2/norm(DC2);
    DC3 = randn(1,3); DC3 = DC3/norm(DC3);
    DC(1,:) = DC1;
    DC(2,:) = DC2;
    DC(3,:) = DC3;
    
    %% Generate World Points
    l = rand(3,1)*480 + [20;20;20];
    QC = zeros(3,3);
    QC(1,:) = PC(1,:) + l(1)*DC(1,:);
    QC(2,:) = PC(2,:) + l(2)*DC(2,:);
    QC(3,:) = PC(3,:) + l(3)*DC(3,:);
    
    %% Apply the transformation to the world point
    % R and t will be the ground trith rotation and translation
    dist = 400;
    t = [dist, 0, 0 ; 0 , dist, 0 ; 0 , 0, dist ]*rand(3,1);
    t = t-([dist;dist;dist]/2); % GROUND TRUTH TRANSLATION
    yaw = 2*rand()*pi;
    pitch = 2*rand()*pi;
    roll = 2*rand()*pi;
    R = angle2dcm( pitch, roll, yaw, 'YXZ' ); % GROUND TRUTH ROTATION
    
    QW = zeros(size(QC));
    QW(1,:) = QC(1,:)/R+t';
    QW(2,:) = QC(2,:)/R+t';
    QW(3,:) = QC(3,:)/R+t';
    
    %% Estimate the pose
    Data = [QW DC PC];
    [Rs1, Ts1, NumSol1, ~] = pose_problem_OUR(Data);
    [Rs5, Ts5, NumSol5, ~] = pose_problem_OUR_CfN(Data);
    [Rs2, Ts2, NumSol2, ~] = pose_problem_NISTER_STEWENIUS(Data); 
    [Rs3, Ts3, NumSol3, ~] = pose_problem_CHEN_CHANG(Data);
    [Rs6, Ts6, NumSol6, ~] = pose_problem_CHEN_CHANG_CfSVD(Data);
    
    ATs = zeros(3,8,NAlgorithms);
    ARs = zeros(3,8*3,NAlgorithms);
    
    ATs(:,1:numel(Ts1(1,:)),1) = Ts1;
    ATs(:,1:numel(Ts2(1,:)),2) = Ts2;
    ATs(:,1:numel(Ts3(1,:)),3) = Ts3;
    ATs(:,1:numel(Ts5(1,:)),5) = Ts5;
    ATs(:,1:numel(Ts6(1,:)),6) = Ts6;
    
    ARs(:,1:numel(Rs1(1,:)),1) = Rs1;
    ARs(:,1:numel(Rs2(1,:)),2) = Rs2;
    ARs(:,1:numel(Rs3(1,:)),3) = Rs3;
    ARs(:,1:numel(Rs5(1,:)),5) = Rs5;
    ARs(:,1:numel(Rs6(1,:)),6) = Rs6;
    
    if isempty(Ts1) || isempty(Ts2) || isempty(Ts3) || isempty(Ts5) || isempty(Ts6)
        iter = iter -1;
        continue
    end
    
    Rgt = inv(R);
    tgt  = -R\t;
    [a b c] = dcm2angle(Rgt);
    
    for iter_alg = 1 : NAlgorithms
        
        if iter_alg == 4, continue; end
        
        %% Display and plot the results
        % Proposed Method Variation
        if PlotHyp == 1, disp(['Algorithm: ', num2str(iter_alg)]); end
        array_err   = zeros(3,numel(ATs(1,:,iter_alg)));
        NumSolConst = numel(ATs(1,:,iter_alg));
        NumSol      = numel(ATs(1,:,iter_alg));
        for i = 1 : numel(ATs(1,:,iter_alg))
            ttest = ATs(:,i,iter_alg);
            Res   = ARs(:,((i-1)*3+1):(i*3),iter_alg);
            if ~isreal(Res) || abs(det(Res) - 1) > 000000.1
                NumSol      = NumSol - 1;
                NumSolConst = NumSolConst - 1;
                continue
            else
                [aest best cest] = dcm2angle(Res);
                
                QCes = Res*QW'+[ttest ttest ttest];
                
                err_angles = norm([aest best cest]-[a b c]);
                err_trans  = norm(ttest-tgt);
                err_dist   = 1/3*(norm(QCes(:,1)-QC(1,:)')+norm(QCes(:,2)-QC(2,:)')+norm(QCes(:,3)-QC(3,:)'));
                array_err(:,i) = [err_angles;err_trans;err_dist];
                if PlotHyp == 1, disp(['Hypothesis: ', num2str(i),'. Rotation Error: ', num2str(err_angles), '. Translation Error', num2str(err_trans)]); end
                if dot(DC(1,:),(QCes(:,1)'-PC(1,:)))<0 || dot(DC(2,:),(QCes(:,2)'-PC(2,:)))<0 || dot(DC(3,:),(QCes(:,3)'-PC(3,:)))<0
                    NumSolConst = NumSolConst - 1;
                end
            end
        end
    
        array_err(:,array_err(1,:)==0) = [];
        if isempty(array_err)
            iter = iter -1;
            continue
        end

        
        numerical_errors_R(iter_alg,iter)  = min(array_err(1,:));
        numerical_errors_T(iter_alg,iter)  = min(array_err(2,:));
        numerical_errors_P(iter_alg,iter)  = min(array_err(3,:));
        numerical_errors_N(iter_alg,iter)  = NumSol;
        numerical_errors_NC(iter_alg,iter) = NumSolConst;
        
    end
    
    
end

TimeALL = toc(TicTimeAll);
disp(['The computation time of the program was: ', num2str(TimeALL/60),'[min]; ',num2str(TimeALL),'[seg]'])

save('data_main_ICCV2013')

PLOT_NE
PLOT_NO

