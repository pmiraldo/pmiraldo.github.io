%% A Robust Parameterization for the General Minimal Pose Problem
% Author: Pedro Miraldo (miraldo@isr.uc.pt)
% Institution: Institute for Systems and Robotics, University of Coimbra
% Results Figure 3(4)
clear all
clc

hyp = input('Subfigure reference [a, c, c]: ','s');
if ~(hyp == 'a' || hyp == 'b' || hyp == 'c')
    disp('ERROR: non-valid option');
    return;
end

if hyp == 'a'
    data_save = 'data_critical_orth.mat';
    fig_name  = 'Figure_C_orth';
    POSMAX = 0;
    POSMIN = -7; % for pushbroom -8, for orthogonal -7
elseif hyp == 'b'
    data_save = 'data_critical_pushbroom.mat';
    fig_name  = 'Figure_C_pushbroom';
    POSMAX = 0;
    POSMIN = -8; % for pushbroom -8, for orthogonal -7
elseif hyp == 'c'
    data_save = 'data_critical_xslit.mat';
    fig_name  = 'Figure_C_xslit';
    POSMAX = 0;
    POSMIN = -8; % for pushbroom -8, for orthogonal -7
end

clc;

warning off; %#ok<WNOFF>

NumIter = 10^3;
PlotHyp = 0;

NAlgorithms = 6;
disp(['The number of iteration is: 10^', num2str(log10(NumIter))]);
NumIterPos = 40;

POSARRAY = logspace(POSMIN,POSMAX,NumIterPos);
disp(['The maximum value for the pose is: 10^',num2str(log10(max(POSARRAY))), ...
    '. Minimum is: 10^', num2str(log10(min(POSARRAY))),'.']);
disp(['The number of iteration for the distribution of the points is: ', num2str(NumIterPos)]);
disp('paused...'); pause;
disp('running...');


POSE_T = zeros(NAlgorithms, NumIterPos);
POSE_R = zeros(NAlgorithms, NumIterPos);
POSE_P = zeros(NAlgorithms, NumIterPos);

POSE_FAIL    = zeros(NAlgorithms, NumIterPos);

TicTimeAll = tic;

for iter_pose = 1 : NumIterPos
    
    %% Variable for the results
    numerical_errors_T = zeros(NAlgorithms, NumIter);
    numerical_errors_R = zeros(NAlgorithms, NumIter);
    numerical_errors_P = zeros(NAlgorithms, NumIter);
    
    numerical_errors_N  = zeros(NAlgorithms, NumIter);
    numerical_errors_NC = zeros(NAlgorithms, NumIter);
        
    ITER_POSE    = zeros(NAlgorithms, 1);
    COUNTER_FAIL = zeros(NAlgorithms, NumIterPos);
    
    disp(num2str(iter_pose))
    
    iter = 0;
    while iter < NumIter
        iter = iter + 1;
        
        %% Generate Data-Set first, case
        %% DEGENERATE CASE - ORTHOGRAPHIC CAMERA
        if hyp == 'a'
            VAR_CUT = -10;
            %% Generate incident points
            dist = 100;
            PC = rand(3,3);
            PC = PC*[dist, 0, 0 ; 0, dist, 0 ; 0, 0, dist];
            PC = PC - ones(size(PC))*[dist/2, 0, 0 ; 0, dist/2, 0 ; 0, 0, dist/2 ];
            
            %% Compute directions
            DC1  = randn(1,3); DC1 = DC1/norm(DC1);
            DC2_ = randn(1,3); DC2_ = DC2_/norm(DC2_);
            DC3_ = randn(1,3); DC3_ = DC3_/norm(DC3_);
            DC2 = DC1 + DC2_*POSARRAY(iter_pose);
            DC3 = DC1 + DC3_*POSARRAY(iter_pose);
            DC = zeros(3,3);
            DC(1,:) = DC1/norm(DC1);
            DC(2,:) = DC2/norm(DC2);
            DC(3,:) = DC3/norm(DC3);
            

            %% Generate Data-Set third, case
            %% PUSHBROOM CAMERAS
        elseif hyp == 'b'
            VAR_CUT = -7;
            dist = 200;
            DIR = randn(1,3);
            DIR = DIR/norm(DIR);
            l = randn(3,1)*dist;
            PC1 = DIR*l(1);
            PC2 = DIR*l(2);
            PC3 = DIR*l(3);
            PC = [PC1;PC2;PC3];
            
            %% Compute directions
            NDC = randn(1,3); NDC = NDC/norm(NDC);
            DC1 = randn(1,3); DC1 = cross(DC1,NDC); DC1 = DC1/norm(DC1);
            DC2 = randn(1,3); DC2 = cross(DC2,NDC); DC2 = DC2/norm(DC2);
            DC3 = randn(1,3); DC3 = cross(DC3,NDC); DC3 = DC3/norm(DC3);
            
            DC1_ = randn(1,3); DC1_ = DC1_/norm(DC1_);
            DC2_ = randn(1,3); DC2_ = DC2_/norm(DC2_);
            DC3_ = randn(1,3); DC3_ = DC3_/norm(DC3_);
            DC1 = DC1 + DC1_*POSARRAY(iter_pose);
            DC2 = DC2 + DC2_*POSARRAY(iter_pose);
            DC3 = DC3 + DC3_*POSARRAY(iter_pose);
            
            DC(1,:) = DC1/norm(DC1);
            DC(2,:) = DC2/norm(DC2);
            DC(3,:) = DC3/norm(DC3);
            
            
        elseif hyp == 'c'
            
            %% Generate Data-Set fourth, case
            %% x-SLIT
            VAR_CUT = -8;
            dist = 200;
            DIR = randn(1,3);
            DIR = DIR/norm(DIR);
            l = randn(3,1)*dist/10;
            PC1 = DIR*l(1);
            PC2 = DIR*l(2);
            PC3 = DIR*l(3);
            PC = [PC1;PC2;PC3];
            
            %% Compute directions
            DIR2 = [randn(1,2),0];
            DIR2 = DIR2/norm(DIR2);
            z = randn(1,1)*dist/20;
            l2 = l*10;
            PC21 = DIR2*l2(1) + [0,0,z];
            PC22 = DIR2*l2(2) + [0,0,z];
            PC23 = DIR2*l2(3) + [0,0,z];
            
            DC1 = PC1-PC21; DC1 = DC1/norm(DC1);
            DC2 = PC2-PC22; DC2 = DC2/norm(DC2);
            DC3 = PC3-PC23; DC3 = DC3/norm(DC3);
            
            DC1_ = randn(1,3); DC1_ = DC1_/norm(DC1_);
            DC2_ = randn(1,3); DC2_ = DC2_/norm(DC2_);
            DC3_ = randn(1,3); DC3_ = DC3_/norm(DC3_);
            DC1 = DC1 + DC1_*POSARRAY(iter_pose);
            DC2 = DC2 + DC2_*POSARRAY(iter_pose);
            DC3 = DC3 + DC3_*POSARRAY(iter_pose);
            
            DC(1,:) = DC1/norm(DC1);
            DC(2,:) = DC2/norm(DC2);
            DC(3,:) = DC3/norm(DC3);
            
            
        end

        %% Generate world points (in the camera referencial)
        % generate three dephs
        l = rand(3,1)*480 + [20;20;20];
        QC = zeros(3,3);
        QC(1,:) = PC(1,:) + l(1)*DC(1,:);
        QC(2,:) = PC(2,:) + l(2)*DC(2,:);
        QC(3,:) = PC(3,:) + l(3)*DC(3,:);
        
        %% Apply the transformation to the world point
        % R and t will be the ground trith rotation and translation
        dist = 400;
        t = [dist, 0, 0 ; 0 , dist, 0 ; 0 , 0, dist ]*rand(3,1);
        t = t-([dist;dist;dist]/2);  % GROUND TRUTH TRANSLATION
        yaw = 2*rand()*pi;
        pitch = 2*rand()*pi;
        roll = 2*rand()*pi;
        R = angle2dcm( pitch, roll, yaw, 'YXZ' ); % GROUND TRUTH ROTATION
        
        QW = zeros(size(QC));
        QW(1,:) = QC(1,:)/R+t';
        QW(2,:) = QC(2,:)/R+t';
        QW(3,:) = QC(3,:)/R+t';
        
        %% Estimate the pose
        Data = [QW DC PC];

        [Rs1, Ts1, NumSol1, ~] = pose_problem_OUR(Data);
    	[Rs5, Ts5, NumSol5, ~] = pose_problem_OUR_CfN(Data);
    	[Rs2, Ts2, NumSol2, ~] = pose_problem_NISTER_STEWENIUS(Data); 
    	[Rs3, Ts3, NumSol3, ~] = pose_problem_CHEN_CHANG(Data);
    	[Rs6, Ts6, NumSol6, ~] = pose_problem_CHEN_CHANG_CfSVD(Data);

        
        LIM_PLOT_NISTER = 10^(VAR_CUT);
        if POSARRAY(iter_pose) < LIM_PLOT_NISTER % ignore the method (does not work)
            Rs2 = Rs1;
            Ts2 = Ts1;
        end
        
        Ts4 = zeros(3,1); Rs4 = eye(3);
        
        
        ATs = zeros(3,8,NAlgorithms);
        ARs = zeros(3,8*3,NAlgorithms);
        
        if ~isempty(Ts1)
            ATs(:,1:numel(Ts1(1,:)),1) = Ts1;
            ARs(:,1:numel(Rs1(1,:)),1) = Rs1;
        end
        
        if ~isempty(Ts2)
            ATs(:,1:numel(Ts2(1,:)),2) = Ts2;
            ARs(:,1:numel(Rs2(1,:)),2) = Rs2;
        end
        
        if ~isempty(Ts3)
            ATs(:,1:numel(Ts3(1,:)),3) = Ts3;
            ARs(:,1:numel(Rs3(1,:)),3) = Rs3;
        end
        if ~isempty(Ts4)
            ATs(:,1:numel(Ts4(1,:)),4) = Ts4;
            ARs(:,1:numel(Rs4(1,:)),4) = Rs4;
        end
        
        if ~isempty(Ts5)
            ATs(:,1:numel(Ts5(1,:)),5) = Ts5;
            ARs(:,1:numel(Rs5(1,:)),5) = Rs5;
        end
        
        if ~isempty(Ts6)
            ATs(:,1:numel(Ts6(1,:)),6) = Ts6;
            ARs(:,1:numel(Rs6(1,:)),6) = Rs6;
        end

        Rgt = inv(R);
        tgt  = -R\t;
        [a b c] = dcm2angle(Rgt);
        

        FAILFLAG = 0;
        for iter_alg = 1 : NAlgorithms
            
            %% Display and plot the results
            % Proposed Method Variation
            if PlotHyp == 1, disp(['Algorithm: ', num2str(iter_alg)]); end
            array_err   = zeros(3,numel(ATs(1,:,iter_alg)));
            NumSolConst = numel(ATs(1,:,iter_alg));
            NumSol      = numel(ATs(1,:,iter_alg));
            for i = 1 : numel(ATs(1,:,iter_alg))
                ttest = ATs(:,i,iter_alg);
                Res   = ARs(:,((i-1)*3+1):(i*3),iter_alg);
                % verify if the rotation matrix belong to SO(3)
                % if doesn't, discard the hypothesis
                if ~isreal(Res) || abs(det(Res) - 1) > 000.1
                    NumSol      = NumSol - 1;
                    NumSolConst = NumSolConst - 1;
                    continue
                else
                    [aest best cest] = dcm2angle(Res);
                    
                    QCes = Res*QW'+[ttest ttest ttest];
                    
                    err_angles = norm([aest best cest]-[a b c]);
                    err_trans  = norm(ttest-tgt);
                    err_dist   = 1/3*(norm(QCes(:,1)-QC(1,:)')+norm(QCes(:,2)-QC(2,:)')+norm(QCes(:,3)-QC(3,:)'));
                    array_err(:,i) = [err_angles;err_trans;err_dist];
                    if PlotHyp == 1, disp(['Hypothesis: ', num2str(i),'. Rotation Error: ', num2str(err_angles), '. Translation Error', num2str(err_trans)]); end
                    if dot(DC(1,:),(QCes(:,1)'-PC(1,:)))<0 || dot(DC(2,:),(QCes(:,2)'-PC(2,:)))<0 || dot(DC(3,:),(QCes(:,3)'-PC(3,:)))<0
                        NumSolConst = NumSolConst - 1;
                    end
                end
            end
            
            array_err(:,array_err(1,:)==0) = [];
            array_err(:,isnan(array_err(1,:))) = [];
            if isempty(array_err)
                %                 disp(['alg__',num2str(iter_alg)])
                COUNTER_FAIL(iter_alg) = COUNTER_FAIL(iter_alg) + 1;
                FAILFLAG = 1;
                continue
            else
                ITER_POSE(iter_alg) = ITER_POSE(iter_alg) + 1;
                if ITER_POSE(iter_alg) <= NumIter
                    numerical_errors_R(iter_alg,ITER_POSE(iter_alg))  = min(array_err(1,:));
                    numerical_errors_T(iter_alg,ITER_POSE(iter_alg))  = min(array_err(2,:));
                    numerical_errors_P(iter_alg,ITER_POSE(iter_alg))  = min(array_err(3,:));
                    numerical_errors_N(iter_alg,ITER_POSE(iter_alg))  = NumSol;
                    numerical_errors_NC(iter_alg,ITER_POSE(iter_alg)) = NumSolConst;
                end
            end
            
            
            
        end
        
        if FAILFLAG == 1
            iter = iter -1;
        end
        
    end
    
    
    for iter_alg = 1 : NAlgorithms
        
        POSE_R(iter_alg,iter_pose) = median(numerical_errors_R(iter_alg,:));
        POSE_T(iter_alg,iter_pose) = median(numerical_errors_T(iter_alg,:));
        POSE_P(iter_alg,iter_pose) = median(numerical_errors_P(iter_alg,:));
        
        POSE_FAIL(iter_alg,iter_pose) = COUNTER_FAIL(iter_alg);
        
    end

end

TimeALL = toc(TicTimeAll);
disp(['The computation time of the program was: ', num2str(TimeALL/60),'[min]; ',num2str(TimeALL),'[seg]'])

save(data_save)

name = fig_name;
PLOT_CRITICAL


