%% A Robust Parameterization for the General Minimal Pose Problem
% Author: Pedro Miraldo (miraldo@isr.uc.pt)
% Institution: Institute for Systems and Robotics, University of Coimbra
%% Plot Resultados Numerical Error
close all

font_size = 25;

color1 = [0.3,0.3,0.7];
color2 = [0.3,0.7,0.3];
color3 = [0.8,0.2,0.2];
color4 = [0.5,0.2,0.1];
color5 = [1,140/255,0];

t = POSARRAY;
z1 = POSE_T(1,:);
z2 = POSE_T(2,:);
z3 = POSE_T(3,:);
z4 = POSE_T(4,:);
z5 = POSE_T(5,:);
z6 = POSE_T(6,:);

aa = t>LIM_PLOT_NISTER;
tt = t(aa);
zz2 = z2(aa);

figure(1)
h = loglog(t,z1,tt,zz2,t,z3,t,z4,t,z5,t,z6,'LineWidth', 5);
set(h(1), 'color', color1);set(h(2), 'color', color2);set(h(3), 'color', color3);set(h(4), 'color', color4);
set(h(5), 'color', color1, 'LineStyle', '--');
set(h(6),'LineStyle', '--', 'color', color3);
uistack(h(4), 'top');uistack(h(3), 'top');uistack(h(2), 'top');uistack(h(5), 'top');uistack(h(1), 'top');
delete(h(4))
grid off
title('Median of the Translaction Error', 'FontSize', font_size+3, 'FontWeight', 'bold')
xlabel('Distance from Critical Case - Base 10', 'FontSize', font_size-5)
ylabel('Base 10', 'FontSize', font_size-12)

P = get(gca, 'XTick'); Pl = log10(P);
P = -16:1:0; P = 10.^P;
set(gca,'XTick',P);
set(gca,'XTickLabel',log10(get(gca, 'XTick')));
P = -16:2:10; P = 10.^P;
set(gca,'YTick',P);
set(gca,'Yticklabel',log10(get(gca, 'YTick')));
set(gca,'FontSize', font_size-12);


set(gca,'box','on');

P = get(gca,'Position');
P(4) = 3/4*P(3);
set(gca,'Position',P);
% set(gca,'XTickLabel',log10(get(gca, 'XTick')));
% set(gca,'YTickLabel',log10(get(gca, 'YTick')));
set(gca,'Xdir','reverse');
axis tight
saveas(gcf,['./ResultFigures/',name,'_a.eps'],'epsc')

t = POSARRAY;
z1 = POSE_R(1,:);
z2 = POSE_R(2,:);
z3 = POSE_R(3,:);
z4 = POSE_R(4,:);
z5 = POSE_R(5,:);
z6 = POSE_R(6,:);

aa = t>LIM_PLOT_NISTER;
tt = t(aa);
zz2 = z2(aa);

figure(2)
h = loglog(t,z1,tt,zz2,t,z3,t,z4,t,z5,t,z6,'LineWidth', 5);
set(h(1), 'color', color1);set(h(2), 'color', color2);set(h(3), 'color', color3);
set(h(6),'LineStyle', '--', 'color', color3);set(h(4), 'color', color4);
set(h(5), 'color', color1, 'LineStyle', '--');
uistack(h(4), 'top');uistack(h(3), 'top');uistack(h(2), 'top');uistack(h(5), 'top');uistack(h(1), 'top');
grid off
delete(h(4))
if hyp == 'a'
hlegend = legend([h(1), h(5), h(2), h(3),h(6)], 'Our', 'Our - CfN', 'Nister and Stewenius', ...
    'Chen and Chang','Chen and Chang - CfSVD',2);
set(hlegend,'FontSize', font_size-6)
end
title('Median of the Rotation Error', 'FontSize', font_size+3, 'FontWeight', 'bold')
xlabel('Distance from Critical Case - Base 10', 'FontSize', font_size-5)
ylabel('Base 10', 'FontSize', font_size-12)

P = get(gca, 'XTick'); Pl = log10(P);
P = -16:1:0; P = 10.^P;
set(gca,'XTick',P);
set(gca,'XTickLabel',log10(get(gca, 'XTick')));
P = -16:2:10; P = 10.^P;
set(gca,'YTick',P);
set(gca,'Yticklabel',log10(get(gca, 'YTick')));
set(gca,'FontSize', font_size-12);


set(gca,'box','on');
P = get(gca,'Position');
P(4) = 3/4*P(3);
set(gca,'Position',P);
% axis([10^(-13.2) 10^(-4) 0 10/9.5*max(max([z1;z2,;z3]))])
% set(gca,'XTickLabel',log10(get(gca, 'XTick')));
% set(gca,'YTickLabel',log10(get(gca, 'YTick')));
set(gca,'Xdir','reverse');
axis tight
saveas(gcf,['./ResultFigures/',name,'_b.eps'],'epsc')

z1 = POSE_FAIL(1,:)';
z2 = POSE_FAIL(2,:)';
z3 = POSE_FAIL(3,:)';
z4 = POSE_FAIL(4,:)';
z5 = POSE_FAIL(5,:)';
z6 = POSE_FAIL(6,:)';


aa = t>LIM_PLOT_NISTER;
tt = t(aa);
zz2 = z2(aa);


figure(11);
hold on
h = zeros(4,1);
h(1) = stairs(t,z1,'linewidth',5);
h(3) = stairs(tt,zz2,'linewidth',5);
h(4) = stairs(t,z3,'linewidth',5);
h(5) = stairs(t,z4,'linewidth',5);
h(2) = stairs(t,z5,'linewidth',5);
h(6) = stairs(t,z6,'linewidth',5);
set(h(1),'color',color1);set(h(2),'color',color1, 'LineStyle', '--');
set(h(3),'color',color2);set(h(4),'color',color3);set(h(5),'color',color4);
set(h(6),'LineStyle', '--', 'color', color3);
uistack(h(4), 'top');uistack(h(3), 'top');uistack(h(2), 'top');uistack(h(5), 'top');uistack(h(1), 'top');
delete(h(5))
title('Failures to get 10^3 Trials', 'FontSize', font_size, 'FontWeight', 'bold')
xlabel('Distance from Critical Case - Base 10', 'FontSize', font_size-2)
ylabel('', 'FontSize', font_size-6)

P = get(gca, 'XTick'); 
Pl = log10(P);
P = -16:1:0; P = 10.^P;
set(gca,'XTick',P);
set(gca,'XTickLabel',log10(get(gca, 'XTick')));
set(gca,'FontSize', font_size-12);

set(gca,'box','on');
P = get(gca,'Position');
P(4) = 3/4*P(3);
set(gca,'Position',P);
% xa = get(gca,'xticklabel');
% ncxa = numel(xa);
% xa = logspace(POSMIN,POSMAX,ncxa);
% set(gca,'xticklabel',log10(xa));
P = axis;
P(2) = 10^(-3);
% P(4) = round(P(4)/2);
axis(P);
set(gca,'XScale','log');
set(gca,'Xdir','reverse');
saveas(gcf,['./ResultFigures/',name,'_c.eps'],'epsc')
hold off