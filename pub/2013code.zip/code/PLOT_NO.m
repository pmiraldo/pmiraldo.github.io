%% A Robust Parameterization for the General Minimal Pose Problem
% Author: Pedro Miraldo (miraldo@isr.uc.pt)
% Institution: Institute for Systems and Robotics, University of Coimbra
%% Plot Resultados Numerical Error

color1 = [0.3,0.3,0.7];
color2 = [0.3,0.7,0.3];
color3 = [0.8,0.2,0.2];
color4 = [0.5,0.2,0.1];

t = logspace(1,max(max(numerical_errors_N)),max(max(numerical_errors_N)));
tc = logspace(1,max(max(numerical_errors_NC)),max(max(numerical_errors_NC)));


z1 = zeros(numel(t),1);
z2 = zeros(numel(t),1);
z3 = zeros(numel(t),1);

zc1 = zeros(numel(tc),1);
zc2 = zeros(numel(tc),1);
zc3 = zeros(numel(tc),1);

% array without constraint
for i = 1 : numel(t)
    array_temp = find(numerical_errors_N(1,:)==i);
    z1(i) = numel(array_temp);
    array_temp = find(numerical_errors_N(2,:)==i);
    z2(i) = numel(array_temp);
    array_temp = find(numerical_errors_N(3,:)==i);
    z3(i) = numel(array_temp);
end

mean_our = dot(t,z1)/numel(numerical_errors_N);

% array with constraint
for i = 1 : numel(tc)
    array_temp = find(numerical_errors_NC(1,:)==i);
    zc1(i) = numel(array_temp);
    array_temp = find(numerical_errors_NC(2,:)==i);
    zc2(i) = numel(array_temp);
    array_temp = find(numerical_errors_NC(3,:)==i);
    zc3(i) = numel(array_temp);
end

%% Plot Everything
z = [z1 z2 z3];

sz1 = 0;
sz2 = 0;
sz3 = 0;
sz4 = 0;
sz5 = 0;
for i = 1 : numel(z(:,1))
    sz1 = sz1+i*z(i,1);
    sz2 = sz2+i*z(i,2);
    sz3 = sz3+i*z(i,3);
end
mz1 = sz1/sum(z(:,1));
mz2 = sz2/sum(z(:,2));
mz3 = sz3/sum(z(:,3));

disp('Mean number of solutions WITHOUT orientation constraint:');
disp(['Our method:           ', num2str(mz1)]);
disp(['Nister and Stewenius: ', num2str(mz2)]);
disp(['Chen and Chang:       ', num2str(mz3)]);


figure(11);
hold on
h = bar(z);
set(h(1),'facecolor',color1);set(h(2),'facecolor',color2);
set(h(3),'facecolor',color3);
title('Without Orientation Contraint', 'FontSize', font_size, 'FontWeight', 'bold');
xlabel('Number of Solutions', 'FontSize', font_size-2)
ylabel('Number of Occurrences in 10^6 Trials', 'FontSize', font_size-6)
hlegend = legend([h(1), h(2), h(3)], 'Our','Nister and Stewenius', ...
    'Chen and Chang');
set(hlegend,'FontSize', font_size-6);
axis([0.5 min([8 numel(t)])+0.5 0 10/9.5*max(max([z1;z2,;z3]))]);
set(gca,'box','on');
P = get(gca,'Position');
P(4) = 3/4*P(3);
set(gca,'Position',P);
set(gca,'yticklabel',{[]}); 
saveas(gcf,'./ResultFigures/Figure_3a1.eps','epsc');
hold off

zc = [zc1 zc2 zc3];

szc1 = 0;
szc2 = 0;
szc3 = 0;
szc4 = 0;
for i = 1 : numel(zc(:,1))
    szc1 = szc1+i*zc(i,1);
    szc2 = szc2+i*zc(i,2);
    szc3 = szc3+i*zc(i,3);
end
mzc1 = szc1/sum(zc(:,1));
mzc2 = szc2/sum(zc(:,2));
mzc3 = szc3/sum(zc(:,3));


disp('Mean number of solutions WITH orientation constraint:');
disp(['Our method:           ', num2str(mzc1)]);
disp(['Nister and Stewenius: ', num2str(mzc2)]);
disp(['Chen and Chang:       ', num2str(mzc3)]);

figure(12);
hold on
colormap(gray);
h = bar(zc);
set(h(1),'facecolor',color1);set(h(2),'facecolor',color2);set(h(3),'facecolor',color3);
title('With Orientation Contraint', 'FontSize', font_size, 'FontWeight', 'bold');
xlabel('Number of Solutions', 'FontSize', font_size-2);
ylabel('Number of Occurrences in 10^6 Trials', 'FontSize', font_size-6);
hlegend = legend([h(1), h(2), h(3)], 'Our', 'Nister and Stewenius', ...
    'Chen and Chang');
set(hlegend,'FontSize', font_size-6);
axis([0.5 min([8 numel(tc)])+0.5 0 10/9.5*max(max([zc1;zc2,;zc3]))]);
set(gca,'box','on');
P = get(gca,'Position');
P(4) = 3/4*P(3);
set(gca,'Position',P);
set(gca,'yticklabel',{[]});
saveas(gcf,'./ResultFigures/Figure_3a2.eps','epsc');
hold off
