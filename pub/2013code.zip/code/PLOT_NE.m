%% A Robust Parameterization for the General Minimal Pose Problem
% Author: Pedro Miraldo (miraldo@isr.uc.pt)
% Institution: Institute for Systems and Robotics, University of Coimbra
%% Plot Resultados Numerical Error
close all

font_size = 25;

color1 = [0.3,0.3,0.7];
color2 = [0.3,0.7,0.3];
color3 = [0.8,0.2,0.2];
color4 = [0.5,0.2,0.1];
color5 = [1,140/255,0];

log_spacing = 100;
t = logspace(-16,0,log_spacing);
z1 = zeros(1,numel(t));
z2 = zeros(1,numel(t));
z3 = zeros(1,numel(t));
z4 = zeros(1,numel(t));
z5 = zeros(1,numel(t));
z6 = zeros(1,numel(t));

numerical_errors_T1 = sort(numerical_errors_T(1,:));
numerical_errors_T2 = sort(numerical_errors_T(2,:));
numerical_errors_T3 = sort(numerical_errors_T(3,:));
numerical_errors_T4 = sort(numerical_errors_T(4,:));
numerical_errors_T5 = sort(numerical_errors_T(5,:));
numerical_errors_T6 = sort(numerical_errors_T(6,:));

for i = 1 : numel(t)-1
    array_numerical_errors_T1 = find(numerical_errors_T1>t(i) & numerical_errors_T1<t(i+1));
    z1(i) = numel(array_numerical_errors_T1);
    
    array_numerical_errors_T2 = find(numerical_errors_T2>t(i) & numerical_errors_T2<t(i+1));
    z2(i) = numel(array_numerical_errors_T2);
    
    array_numerical_errors_T3 = find(numerical_errors_T3>t(i) & numerical_errors_T3<t(i+1));
    z3(i) = numel(array_numerical_errors_T3);
    
    array_numerical_errors_T4 = find(numerical_errors_T4>t(i) & numerical_errors_T4<t(i+1));
    z4(i) = numel(array_numerical_errors_T4);
    
    array_numerical_errors_T5 = find(numerical_errors_T5>t(i) & numerical_errors_T5<t(i+1));
    z5(i) = numel(array_numerical_errors_T5);
    
    array_numerical_errors_T6 = find(numerical_errors_T6>t(i) & numerical_errors_T6<t(i+1));
    z6(i) = numel(array_numerical_errors_T6);
end

disp('Integral of the curves')
disp(['Our             : ', num2str(sum(z1(:)))])
disp(['Nister          : ', num2str(sum(z2(:)))])
disp(['Chen            : ', num2str(sum(z3(:)))])
disp(['Our - Direct    : ', num2str(sum(z5(:)))])

disp(['OUR          Translation mediana: ', num2str(median(numerical_errors_T1))])
disp(['NISTER       Translation mediana: ', num2str(median(numerical_errors_T2))])
disp(['CHEN         Translation mediana: ', num2str(median(numerical_errors_T3))])
disp(['Our - Direct Translation mediana: ', num2str(median(numerical_errors_T5))])

[~,imz1] = max(z1);
[~,imz2] = max(z2);
[~,imz3] = max(z3);
[~,imz4] = max(z4);
[~,imz5] = max(z5);
[~,imz6] = max(z6);

disp(['OUR          Translation moda: ', num2str(t(imz1))])
disp(['NISTER       Translation moda: ', num2str(t(imz2))])
disp(['CHEN         Translation moda: ', num2str(t(imz3))])
disp(['Our - Direct Translation moda: ', num2str(t(imz5))])
disp('--')

figure(1)
h = semilogx(t,z1,t,z2,t,z3,t,z4,t,z5,t,z6,'LineWidth', 5);
set(h(1), 'color', color1);set(h(5),'LineStyle','--','color', color1);set(h(2), 'color', color2);set(h(3), 'color', color3);set(h(4), 'color', color4);
set(h(6),'LineStyle','--','color', color3)
uistack(h(2), 'top');uistack(h(5), 'top');uistack(h(1), 'top');
delete(h(4));
grid off
title('Distribution of the Translaction Error', 'FontSize', font_size+3, 'FontWeight', 'bold')
xlabel('Base 10 Logarithm of the Numerical Error', 'FontSize', font_size-5)
ylabel('Number of Occurrences in 10^6 Trials', 'FontSize', font_size-9)
% hlegend = legend([h(1), h(5), h(2), h(3), h(4)], 'Our - Orth.', 'Our - Direct', 'Nister and Stewenius', ...
%     'Chen and Chang', 'Ramalingam + QI');
% set(hlegend,'FontSize', font_size-6);
axis([10^(-14) 10^(-6) 0 10/9.5*max(max([z1;z2,;z3]))])
set(gca, 'XTick',logspace(-16,0,9))
set(gca,'XTickLabel',log10(get(gca, 'XTick')));
set(gca,'yticklabel',{[]}) 
set(gca,'box','on');
P = get(gca,'Position');
P(4) = 3/4*P(3);
set(gca,'Position',P);
% axis tight
saveas(gcf,'./ResultFigures/Figure_2a2.eps','epsc')

% rotation
t = logspace(-16,0,log_spacing);
z1 = zeros(1,numel(t));
z2 = zeros(1,numel(t));
z3 = zeros(1,numel(t));
z4 = zeros(1,numel(t));
z5 = zeros(1,numel(t));
z6 = zeros(1,numel(t));

numerical_errors_R1 = sort(numerical_errors_R(1,:));
numerical_errors_R2 = sort(numerical_errors_R(2,:));
numerical_errors_R3 = sort(numerical_errors_R(3,:));
numerical_errors_R4 = sort(numerical_errors_R(4,:));
numerical_errors_R5 = sort(numerical_errors_R(5,:));
numerical_errors_R6 = sort(numerical_errors_R(6,:));

for i = 1 : numel(t)-1
    array_numerical_errors_R1 = find(numerical_errors_R1>t(i) & numerical_errors_R1<t(i+1));
    z1(i) = numel(array_numerical_errors_R1);
    
    array_numerical_errors_R2 = find(numerical_errors_R2>t(i) & numerical_errors_R2<t(i+1));
    z2(i) = numel(array_numerical_errors_R2);
    
    array_numerical_errors_R3 = find(numerical_errors_R3>t(i) & numerical_errors_R3<t(i+1));
    z3(i) = numel(array_numerical_errors_R3);
    
    array_numerical_errors_R4 = find(numerical_errors_R4>t(i) & numerical_errors_R4<t(i+1));
    z4(i) = numel(array_numerical_errors_R4);
    
    array_numerical_errors_R5 = find(numerical_errors_R5>t(i) & numerical_errors_R5<t(i+1));
    z5(i) = numel(array_numerical_errors_R5);
    
    array_numerical_errors_R6 = find(numerical_errors_R6>t(i) & numerical_errors_R6<t(i+1));
    z6(i) = numel(array_numerical_errors_R6);
end

disp('Integral of the curves')
disp(['Our             : ', num2str(sum(z1(:)))])
disp(['Nister          : ', num2str(sum(z2(:)))])
disp(['Chen            : ', num2str(sum(z3(:)))])
disp(['Our - Direct    : ', num2str(sum(z5(:)))])

disp(['OUR          Rotation mediana: ', num2str(median(numerical_errors_R1))])
disp(['NISTER       Rotation mediana: ', num2str(median(numerical_errors_R2))])
disp(['CHEN         Rotation mediana: ', num2str(median(numerical_errors_R3))])
disp(['Our - Direct Rotation mediana: ', num2str(median(numerical_errors_R5))])

[~,imz1 ] = max(z1);
[~,imz2 ] = max(z2);
[~,imz3 ] = max(z3);
[~,imz4 ] = max(z4);
[~,imz5 ] = max(z5);
[~,imz6 ] = max(z6);

disp(['OUR           Rotation moda: ', num2str(t(imz1))])
disp(['NISTER        Rotation moda: ', num2str(t(imz2))])
disp(['CHEN          Rotation moda: ', num2str(t(imz3))])
disp(['Our - Direct  Rotation moda: ', num2str(t(imz5))])
disp('--')

figure(2)
% h = semilogx(t,z1,'-k',t,z2, '--k',t,z4, '-.k',t,z3,':k','LineWidth', 3);
h = semilogx(t,z1,t,z2,t,z3,t,z4,t,z5,t,z6,'LineWidth', 5);
set(h(1), 'color', color1);set(h(5), 'LineStyle', '--', 'color', color1);set(h(2), 'color', color2);set(h(3), 'color', color3);set(h(4), 'color', color4);
set(h(6), 'LineStyle', '--', 'color', color3);
uistack(h(2), 'top');uistack(h(5), 'top');uistack(h(1), 'top');
delete(h(4));
grid off
title('Distribution of the Rotation Error', 'FontSize', font_size+3, 'FontWeight', 'bold')
xlabel('Base 10 Logarithm of the Numerical Error', 'FontSize', font_size-5)
ylabel('Number of Occurrences in 10^6 Trials', 'FontSize', font_size-9)
hlegend = legend([h(1), h(5), h(2), h(3), h(6)], 'Our', 'Our - CfN', 'Nister and Stewenius', ...
    'Chen and Chang', 'Chen and Chang - CfSVD'); 
set(hlegend,'FontSize', font_size-6);
axis([10^(-16) 10^(-6) 0 10/9.5*max(max([z1;z2,;z3]))])
set(gca, 'XTick',logspace(-16,0,9))
set(gca,'yticklabel',{[]}) 
set(gca,'XTickLabel',log10(get(gca, 'XTick')));
set(gca,'box','on');
P = get(gca,'Position');
P(4) = 3/4*P(3);
set(gca,'Position',P);
% axis tight
saveas(gcf,'./ResultFigures/Figure_2a1.eps','epsc')


