%% A Robust Parameterization for the General Minimal Pose Problem
% Author: Pedro Miraldo (miraldo@isr.uc.pt)
% Institution: Institute for Systems and Robotics, University of Coimbra
function [NRs, NTs, NNumSol, Computation_Time] = pose_problem_NISTER_STEWENIUS(Point_Line)


NNumSol = [];

d1 = Point_Line(1,4:6)';
d1 = d1/norm(d1);
d2 = Point_Line(2,4:6)';
d2 = d2/norm(d2);
d3 = Point_Line(3,4:6)';
d3 = d3/norm(d3);
%
p1 = Point_Line(1,7:9)';
p2 = Point_Line(2,7:9)';
p3 = Point_Line(3,7:9)';
%
q1 = Point_Line(1,1:3)';
q2 = Point_Line(2,1:3)';
q3 = Point_Line(3,1:3)';

%% 1 passo
%  Lining up the rays

tic_Time_ALL = tic;

d11 = d1(1); d12 = d1(2); d13 = d1(3);
d21 = d2(1); d22 = d2(2); d23 = d2(3);
d31 = d3(1); d32 = d3(2); d33 = d3(3);

p11 = p1(1); p12 = p1(2); p13 = p1(3);
p21 = p2(1); p22 = p2(2); p23 = p2(3);
p31 = p3(1); p32 = p3(2); p33 = p3(3);


d4_ = ((d11*d22 - d12*d21)^2 + (d11*d23 - d13*d21)^2 + (d12*d23 - d13*d22)^2)^(1/2);
d41 =  (d12*d23 - d13*d22)/d4_;
d42 = -(d11*d23 - d13*d21)/d4_;
d43 =  (d11*d22 - d12*d21)/d4_;

d51 =  (d12*(d11*d22 - d12*d21))/d4_ + (d13*(d11*d23 - d13*d21))/d4_;
d52 =  (d13*(d12*d23 - d13*d22))/d4_ - (d11*(d11*d22 - d12*d21))/d4_;
d53 = -(d11*(d11*d23 - d13*d21))/d4_ - (d12*(d12*d23 - d13*d22))/d4_;

r11 = d51; r12 = d52; r13 = d53;
r21 = d11; r22 = d12; r23 = d13;
r31 = d41; r32 = d42; r33 = d43;

s = -(d11*d21 + d12*d22 + d13*d23)/(d22*((d11*(d11*d22 - d12*d21))/d4_ - (d13*(d12*d23 - d13*d22))/d4_) - d21*((d12*(d11*d22 - d12*d21))/d4_ + (d13*(d11*d23 - d13*d21))/d4_) + d23*((d11*(d11*d23 - d13*d21))/d4_ + (d12*(d12*d23 - d13*d22))/d4_));
alpha = - (p11 - p21)*(d11 + (d51*(d11*d21 + d12*d22 + d13*d23))/(d22*((d11*(d11*d22 - d12*d21))/d4_ - (d13*(d12*d23 - d13*d22))/d4_) - d21*((d12*(d11*d22 - d12*d21))/d4_ + (d13*(d11*d23 - d13*d21))/d4_) + d23*((d11*(d11*d23 - d13*d21))/d4_ + (d12*(d12*d23 - d13*d22))/d4_))) - (p12 - p22)*(d12 + (d52*(d11*d21 + d12*d22 + d13*d23))/(d22*((d11*(d11*d22 - d12*d21))/d4_ - (d13*(d12*d23 - d13*d22))/d4_) - d21*((d12*(d11*d22 - d12*d21))/d4_ + (d13*(d11*d23 - d13*d21))/d4_) + d23*((d11*(d11*d23 - d13*d21))/d4_ + (d12*(d12*d23 - d13*d22))/d4_))) - (p13 - p23)*(d13 + (d53*(d11*d21 + d12*d22 + d13*d23))/(d22*((d11*(d11*d22 - d12*d21))/d4_ - (d13*(d12*d23 - d13*d22))/d4_) - d21*((d12*(d11*d22 - d12*d21))/d4_ + (d13*(d11*d23 - d13*d21))/d4_) + d23*((d11*(d11*d23 - d13*d21))/d4_ + (d12*(d12*d23 - d13*d22))/d4_)));

p41 = p11 + alpha*d11;
p42 = p12 + alpha*d12;
p43 = p13 + alpha*d13;

rp41 = -(r11*p41+r12*p42+r13*p43);
rp42 = -(r21*p41+r22*p42+r23*p43);
rp43 = -(r31*p41+r32*p42+r33*p43);

h11 = r11; h12 = r12; h13 = r13; h14 = rp41;
h21 = r21; h22 = r22; h23 = r23; h24 = rp42;
h31 = r31; h32 = r32; h33 = r33; h34 = rp43;

dH1  = (h11*h22*h33 - h11*h23*h32 - h12*h21*h33 + h12*h23*h31 + h13*h21*h32 - h13*h22*h31);
ih11 = (h22*h33 - h23*h32)/dH1;ih12 = -(h12*h33 - h13*h32)/dH1;ih13 = (h12*h23 - h13*h22)/dH1;
ih14 = -(h12*h23*h34 - h12*h24*h33 - h13*h22*h34 + h13*h24*h32 + h14*h22*h33 - h14*h23*h32)/dH1;
ih21 = -(h21*h33 - h23*h31)/dH1;ih22 = (h11*h33 - h13*h31)/dH1;ih23 = -(h11*h23 - h13*h21)/dH1;
ih24 = (h11*h23*h34 - h11*h24*h33 - h13*h21*h34 + h13*h24*h31 + h14*h21*h33 - h14*h23*h31)/dH1;
ih31 = (h21*h32 - h22*h31)/dH1;ih32 = -(h11*h32 - h12*h31)/dH1;ih33 = (h11*h22 - h12*h21)/dH1;
ih34 = -(h11*h22*h34 - h11*h24*h32 - h12*h21*h34 + h12*h24*h31 + h14*h21*h32 - h14*h22*h31)/dH1;

d31_ = r11*d31+r12*d32+r13*d33;
d32_ = r21*d31+r22*d32+r23*d33;
d33_ = r31*d31+r32*d32+r33*d33;
d31 = d31_;d32 = d32_;d33 = d33_;

p23_ = r31*p21+r32*p22+r33*p23 + rp43;
p23 = p23_;

p31_ = r11*p31+r12*p32+r13*p33 + rp41;
p32_ = r21*p31+r22*p32+r23*p33 + rp42;
p33_ = r31*p31+r32*p32+r33*p33 + rp43;
p31 = p31_;p32 = p32_;p33 = p33_;

%% 2 passo
% Lining Up the Points
q11 = q1(1); q12 = q1(2); q13 = q1(3);
q21 = q2(1); q22 = q2(2); q23 = q2(3);
q31 = q3(1); q32 = q3(2); q33 = q3(3);

e  = p23;
D = ((q11 - q21)^2 + (q12 - q22)^2 + (q13 - q23)^2 - e^2)^(1/2);
D_ = ((q11 - q21)^2 + (q12 - q22)^2 + (q13 - q23)^2)^(1/2);

d61 = D/D_;d62 = 0;d63 = e/D_;
d71 = (q21-q11)/D_;d72 = (q22-q12)/D_;d73 = (q23-q13)/D_;
d81 = 0;d82 = 1;d83 = 0;

d9_ = ((d72*(q11 - q31) - d71*(q12 - q32))^2 + (d73*(q11 - q31) - d71*(q13 - q33))^2 + (d73*(q12 - q32) - d72*(q13 - q33))^2)^(1/2);
d91 =  (d73*(q12 - q32) - d72*(q13 - q33))/d9_;
d92 = -(d73*(q11 - q31) - d71*(q13 - q33))/d9_;
d93 =  (d72*(q11 - q31) - d71*(q12 - q32))/d9_;

rr11 = d61*d71 + d81*d91 + (d62*d83 - d63*d82)*(d72*d93 - d73*d92);
rr12 = d61*d72 + d81*d92 - (d62*d83 - d63*d82)*(d71*d93 - d73*d91);
rr13 = d61*d73 + d81*d93 + (d62*d83 - d63*d82)*(d71*d92 - d72*d91);
rr21 = d62*d71 + d82*d91 - (d61*d83 - d63*d81)*(d72*d93 - d73*d92);
rr22 = d62*d72 + d82*d92 + (d61*d83 - d63*d81)*(d71*d93 - d73*d91);
rr23 = d62*d73 + d82*d93 - (d61*d83 - d63*d81)*(d71*d92 - d72*d91);
rr31 = d63*d71 + d83*d91 + (d61*d82 - d62*d81)*(d72*d93 - d73*d92);
rr32 = d63*d72 + d83*d92 - (d61*d82 - d62*d81)*(d71*d93 - d73*d91);
rr33 = d63*d73 + d83*d93 + (d61*d82 - d62*d81)*(d71*d92 - d72*d91);

rrq11 = -(rr11*q11+rr12*q12+rr13*q13);
rrq12 = -(rr21*q11+rr22*q12+rr23*q13);
rrq13 = -(rr31*q11+rr32*q12+rr33*q13);

hh11 = rr11; hh12 = rr12; hh13 = rr13; hh14 = rrq11;
hh21 = rr21; hh22 = rr22; hh23 = rr23; hh24 = rrq12;
hh31 = rr31; hh32 = rr32; hh33 = rr33; hh34 = rrq13;

q11_ = rr11*q11 + rr12*q12 + rr13*q13 + rrq11;
q12_ = rr21*q11 + rr22*q12 + rr23*q13 + rrq12;
q13_ = rr31*q11 + rr32*q12 + rr33*q13 + rrq13;
q11 = q11_; q12 = q12_; q13 = q13_;

q21_ = rr11*q21 + rr12*q22 + rr13*q23 + rrq11;
q22_ = rr21*q21 + rr22*q22 + rr23*q23 + rrq12;
q23_ = rr31*q21 + rr32*q22 + rr33*q23 + rrq13;
q21 = q21_; q22 = q22_; q23 = q23_;

q31_ = rr11*q31 + rr12*q32 + rr13*q33 + rrq11;
q32_ = rr21*q31 + rr22*q32 + rr23*q33 + rrq12;
q33_ = rr31*q31 + rr32*q32 + rr33*q33 + rrq13;
q31 = q31_; q32 = q32_; q33 = q33_;

%% 3 step
t1n1 = 0; t1n2 = d33; t1n3 = -d32;
t2n1 = -d33; t2n2 = 0; t2n3 = d31;

if t1n1*t1n1 + t1n2*t1n2 + t1n3*t1n3 > t2n1*t2n1 + t2n2*t2n2 + t2n3*t2n3
    nl1 = -d33*d33-d32*d32; nl2 = d31*d32; nl3 = d31*d33;
    
    l1 = t1n1;l2 = t1n2;l3 = t1n3;
    l4 = -(t1n1*p31 + t1n2*p32 + t1n3*p33);
    
    ll1 = nl1; ll2 = nl2; ll3 = nl3;
    ll4 = -(nl1*p31 + nl2*p32 + nl3*p33);
else
    nl1 = d31*d32; nl2 = -d33*d33-d31*d31; nl3 = d32*d33;
    
    l1 = t2n1;l2 = t2n2;l3 = t2n3;
    l4 = -(t2n1*p31 + t2n2*p32 + t2n3*p33);
    
    ll1 = nl1; ll2 = nl2; ll3 = nl3;
    ll4 = -(nl1*p31 + nl2*p32 + nl3*p33);
end

%% 4 step

% coefficient parameters k2
b1 = - e^2/D^2 - 1;
b2 = (2*d61*e*q31*(q11^2 - 2*q11*q21 + q12^2 - 2*q12*q22 + q13^2 - 2*q13*q23 + q21^2 + q22^2 + q23^2)^(1/2))/D^2 + (2*d62*e*q32*(q11^2 - 2*q11*q21 + q12^2 - 2*q12*q22 + q13^2 - 2*q13*q23 + q21^2 + q22^2 + q23^2)^(1/2))/D^2 + (2*d63*e*q33*(q11^2 - 2*q11*q21 + q12^2 - 2*q12*q22 + q13^2 - 2*q13*q23 + q21^2 + q22^2 + q23^2)^(1/2))/D^2;
b3 = q31^2 + q32^2 + q33^2 - (d61^2*q11^2*q31^2)/D^2 - (d61^2*q12^2*q31^2)/D^2 - (d61^2*q13^2*q31^2)/D^2 - (d62^2*q11^2*q32^2)/D^2 - (d62^2*q12^2*q32^2)/D^2 - (d62^2*q13^2*q32^2)/D^2 - (d63^2*q11^2*q33^2)/D^2 - (d63^2*q12^2*q33^2)/D^2 - (d63^2*q13^2*q33^2)/D^2 - (d61^2*q21^2*q31^2)/D^2 - (d61^2*q22^2*q31^2)/D^2 - (d61^2*q23^2*q31^2)/D^2 - (d62^2*q21^2*q32^2)/D^2 - (d62^2*q22^2*q32^2)/D^2 - (d62^2*q23^2*q32^2)/D^2 - (d63^2*q21^2*q33^2)/D^2 - (d63^2*q22^2*q33^2)/D^2 - (d63^2*q23^2*q33^2)/D^2 + (2*d61^2*q11*q21*q31^2)/D^2 + (2*d61^2*q12*q22*q31^2)/D^2 + (2*d62^2*q11*q21*q32^2)/D^2 + (2*d61^2*q13*q23*q31^2)/D^2 + (2*d62^2*q12*q22*q32^2)/D^2 + (2*d63^2*q11*q21*q33^2)/D^2 + (2*d62^2*q13*q23*q32^2)/D^2 + (2*d63^2*q12*q22*q33^2)/D^2 + (2*d63^2*q13*q23*q33^2)/D^2 - (2*d61*d62*q11^2*q31*q32)/D^2 - (2*d61*d62*q12^2*q31*q32)/D^2 - (2*d61*d62*q13^2*q31*q32)/D^2 - (2*d61*d63*q11^2*q31*q33)/D^2 - (2*d61*d63*q12^2*q31*q33)/D^2 - (2*d61*d63*q13^2*q31*q33)/D^2 - (2*d62*d63*q11^2*q32*q33)/D^2 - (2*d62*d63*q12^2*q32*q33)/D^2 - (2*d62*d63*q13^2*q32*q33)/D^2 - (2*d61*d62*q21^2*q31*q32)/D^2 - (2*d61*d62*q22^2*q31*q32)/D^2 - (2*d61*d62*q23^2*q31*q32)/D^2 - (2*d61*d63*q21^2*q31*q33)/D^2 - (2*d61*d63*q22^2*q31*q33)/D^2 - (2*d61*d63*q23^2*q31*q33)/D^2 - (2*d62*d63*q21^2*q32*q33)/D^2 - (2*d62*d63*q22^2*q32*q33)/D^2 - (2*d62*d63*q23^2*q32*q33)/D^2 + (4*d61*d62*q11*q21*q31*q32)/D^2 + (4*d61*d62*q12*q22*q31*q32)/D^2 + (4*d61*d63*q11*q21*q31*q33)/D^2 + (4*d61*d62*q13*q23*q31*q32)/D^2 + (4*d61*d63*q12*q22*q31*q33)/D^2 + (4*d62*d63*q11*q21*q32*q33)/D^2 + (4*d61*d63*q13*q23*q31*q33)/D^2 + (4*d62*d63*q12*q22*q32*q33)/D^2 + (4*d62*d63*q13*q23*q32*q33)/D^2;
% coefficient parameters k13
a1 = D*l2*ll1*s - D*l1*ll2*s;
% coefficient parameters k14
a2 = l1*ll2 - l2*ll1;
a3 = e*l2*ll1 - e*l1*ll2;
a4 = l2*ll1*q31^2 - l1*ll2*q31^2 - l1*ll2*q32^2 + l2*ll1*q32^2 - l1*ll2*q33^2 + l2*ll1*q33^2 + d61*l1*ll2*q31*(q11^2 - 2*q11*q21 + q12^2 - 2*q12*q22 + q13^2 - 2*q13*q23 + q21^2 + q22^2 + q23^2)^(1/2) - d61*l2*ll1*q31*(q11^2 - 2*q11*q21 + q12^2 - 2*q12*q22 + q13^2 - 2*q13*q23 + q21^2 + q22^2 + q23^2)^(1/2) + d62*l1*ll2*q32*(q11^2 - 2*q11*q21 + q12^2 - 2*q12*q22 + q13^2 - 2*q13*q23 + q21^2 + q22^2 + q23^2)^(1/2) - d62*l2*ll1*q32*(q11^2 - 2*q11*q21 + q12^2 - 2*q12*q22 + q13^2 - 2*q13*q23 + q21^2 + q22^2 + q23^2)^(1/2) + d63*l1*ll2*q33*(q11^2 - 2*q11*q21 + q12^2 - 2*q12*q22 + q13^2 - 2*q13*q23 + q21^2 + q22^2 + q23^2)^(1/2) - d63*l2*ll1*q33*(q11^2 - 2*q11*q21 + q12^2 - 2*q12*q22 + q13^2 - 2*q13*q23 + q21^2 + q22^2 + q23^2)^(1/2);
% coefficient parameters k15
a5 = l1*ll3 - l3*ll1;
a6 = l1*ll4 - l4*ll1;
% coefficient parameters k16
a7 = (e*l2*ll3)/D - (e*l3*ll2)/D;
a8 = D*l2*ll3 - D*l3*ll2 + (e*l2*ll4)/D - (e*l4*ll2)/D - (d61*l2*ll3*q31*(q11^2 - 2*q11*q21 + q12^2 - 2*q12*q22 + q13^2 - 2*q13*q23 + q21^2 + q22^2 + q23^2)^(1/2))/D + (d61*l3*ll2*q31*(q11^2 - 2*q11*q21 + q12^2 - 2*q12*q22 + q13^2 - 2*q13*q23 + q21^2 + q22^2 + q23^2)^(1/2))/D - (d62*l2*ll3*q32*(q11^2 - 2*q11*q21 + q12^2 - 2*q12*q22 + q13^2 - 2*q13*q23 + q21^2 + q22^2 + q23^2)^(1/2))/D + (d62*l3*ll2*q32*(q11^2 - 2*q11*q21 + q12^2 - 2*q12*q22 + q13^2 - 2*q13*q23 + q21^2 + q22^2 + q23^2)^(1/2))/D - (d63*l2*ll3*q33*(q11^2 - 2*q11*q21 + q12^2 - 2*q12*q22 + q13^2 - 2*q13*q23 + q21^2 + q22^2 + q23^2)^(1/2))/D + (d63*l3*ll2*q33*(q11^2 - 2*q11*q21 + q12^2 - 2*q12*q22 + q13^2 - 2*q13*q23 + q21^2 + q22^2 + q23^2)^(1/2))/D;
a9 = D*l2*ll4 - D*l4*ll2 - (d61*l2*ll4*q31*(q11^2 - 2*q11*q21 + q12^2 - 2*q12*q22 + q13^2 - 2*q13*q23 + q21^2 + q22^2 + q23^2)^(1/2))/D + (d61*l4*ll2*q31*(q11^2 - 2*q11*q21 + q12^2 - 2*q12*q22 + q13^2 - 2*q13*q23 + q21^2 + q22^2 + q23^2)^(1/2))/D - (d62*l2*ll4*q32*(q11^2 - 2*q11*q21 + q12^2 - 2*q12*q22 + q13^2 - 2*q13*q23 + q21^2 + q22^2 + q23^2)^(1/2))/D + (d62*l4*ll2*q32*(q11^2 - 2*q11*q21 + q12^2 - 2*q12*q22 + q13^2 - 2*q13*q23 + q21^2 + q22^2 + q23^2)^(1/2))/D - (d63*l2*ll4*q33*(q11^2 - 2*q11*q21 + q12^2 - 2*q12*q22 + q13^2 - 2*q13*q23 + q21^2 + q22^2 + q23^2)^(1/2))/D + (d63*l4*ll2*q33*(q11^2 - 2*q11*q21 + q12^2 - 2*q12*q22 + q13^2 - 2*q13*q23 + q21^2 + q22^2 + q23^2)^(1/2))/D;
% coefficient parameters k17
a10 = l3*ll2 - l2*ll3;
a11 = l4*ll2 - l2*ll4;
% coefficient parameters k18
a12 = (e*l1*ll3)/D - (e*l3*ll1)/D;
a13 = (e*l1*ll4)/D - (e*l4*ll1)/D - D*l2*ll3*s + D*l3*ll2*s - (d61*l1*ll3*q31*(q11^2 - 2*q11*q21 + q12^2 - 2*q12*q22 + q13^2 - 2*q13*q23 + q21^2 + q22^2 + q23^2)^(1/2))/D + (d61*l3*ll1*q31*(q11^2 - 2*q11*q21 + q12^2 - 2*q12*q22 + q13^2 - 2*q13*q23 + q21^2 + q22^2 + q23^2)^(1/2))/D - (d62*l1*ll3*q32*(q11^2 - 2*q11*q21 + q12^2 - 2*q12*q22 + q13^2 - 2*q13*q23 + q21^2 + q22^2 + q23^2)^(1/2))/D + (d62*l3*ll1*q32*(q11^2 - 2*q11*q21 + q12^2 - 2*q12*q22 + q13^2 - 2*q13*q23 + q21^2 + q22^2 + q23^2)^(1/2))/D - (d63*l1*ll3*q33*(q11^2 - 2*q11*q21 + q12^2 - 2*q12*q22 + q13^2 - 2*q13*q23 + q21^2 + q22^2 + q23^2)^(1/2))/D + (d63*l3*ll1*q33*(q11^2 - 2*q11*q21 + q12^2 - 2*q12*q22 + q13^2 - 2*q13*q23 + q21^2 + q22^2 + q23^2)^(1/2))/D;
a14 = D*l4*ll2*s - D*l2*ll4*s - (d61*l1*ll4*q31*(q11^2 - 2*q11*q21 + q12^2 - 2*q12*q22 + q13^2 - 2*q13*q23 + q21^2 + q22^2 + q23^2)^(1/2))/D + (d61*l4*ll1*q31*(q11^2 - 2*q11*q21 + q12^2 - 2*q12*q22 + q13^2 - 2*q13*q23 + q21^2 + q22^2 + q23^2)^(1/2))/D - (d62*l1*ll4*q32*(q11^2 - 2*q11*q21 + q12^2 - 2*q12*q22 + q13^2 - 2*q13*q23 + q21^2 + q22^2 + q23^2)^(1/2))/D + (d62*l4*ll1*q32*(q11^2 - 2*q11*q21 + q12^2 - 2*q12*q22 + q13^2 - 2*q13*q23 + q21^2 + q22^2 + q23^2)^(1/2))/D - (d63*l1*ll4*q33*(q11^2 - 2*q11*q21 + q12^2 - 2*q12*q22 + q13^2 - 2*q13*q23 + q21^2 + q22^2 + q23^2)^(1/2))/D + (d63*l4*ll1*q33*(q11^2 - 2*q11*q21 + q12^2 - 2*q12*q22 + q13^2 - 2*q13*q23 + q21^2 + q22^2 + q23^2)^(1/2))/D;
% coefficient parameters k19
m1 = a2^2 - b1*a5^2 - a7^2 - b1*a10^2 - a12^2;
m2 = - b2*a5^2 - 2*a6*b1*a5 - b2*a10^2 - 2*a11*b1*a10 + 2*a2*a3 - 2*a7*a8 - 2*a12*a13;
m3 = b1*a1^2 + a3^2 - b3*a5^2 - 2*b2*a5*a6 - b1*a6^2 - a8^2 - b3*a10^2 - 2*b2*a10*a11 - b1*a11^2 - a13^2 + 2*a2*a4 - 2*a7*a9 - 2*a12*a14;
m4 = b2*a1^2 - b2*a6^2 - 2*a5*b3*a6 - b2*a11^2 - 2*a10*b3*a11 + 2*a3*a4 - 2*a8*a9 - 2*a13*a14;
m5 = b3*a1^2 + a4^2 - b3*a6^2 - a9^2 - b3*a11^2 - a14^2;
% coefficient parameters k20
m6 = 2*a5*a7 + 2*a10*a12;
m7 = 2*a5*a8 - 2*a1*a2 + 2*a6*a7 + 2*a10*a13 + 2*a11*a12;
m8 = 2*a5*a9 - 2*a1*a3 + 2*a6*a8 + 2*a10*a14 + 2*a11*a13;
m9 = 2*a6*a9 - 2*a1*a4 + 2*a11*a14;

c1 = m5^2 - b3*m9^2;
c2 = - b2*m9^2 - 2*b3*m8*m9 + 2*m4*m5;
c3 = 2*m3*m5 - b3*(m8^2 + 2*m7*m9) - b1*m9^2 + m4^2 - 2*b2*m8*m9;
c4 = 2*m2*m5 - b2*(m8^2 + 2*m7*m9) + 2*m3*m4 - b3*(2*m6*m9 + 2*m7*m8) - 2*b1*m8*m9;
c5 = m3^2 - b3*(m7^2 + 2*m6*m8) - b1*(m8^2 + 2*m7*m9) + 2*m1*m5 + 2*m2*m4 - b2*(2*m6*m9 + 2*m7*m8);
c6 = 2*m1*m4 - b2*(m7^2 + 2*m6*m8) + 2*m2*m3 - b1*(2*m6*m9 + 2*m7*m8) - 2*b3*m6*m7;
c7 = 2*m1*m3 - b1*(m7^2 + 2*m6*m8) - b3*m6^2 + m2^2 - 2*b2*m6*m7;
c8 = - b2*m6^2 - 2*b1*m7*m6 + 2*m1*m2;
c9 = m1^2 - b1*m6^2;

%% quinto step
M = [-c8/c9, -c7/c9, -c6/c9, -c5/c9, -c4/c9, -c3/c9, -c2/c9, -c1/c9 ;eye(7) zeros(7,1)];
[~,sz] = eig(M);
sz = diag(sz);
% remove the imaginary solutions
sz = sz(sz == real(sz));

Numhyp = numel(sz);

%% Recover the pose
NRs = zeros(3,3*Numhyp);
NTs = zeros(3,Numhyp);
for i = 1 : Numhyp
    
    zz = sz(i);
        
    k1 = -(e/D)*zz + (D_*(q31*d61+q32*d62+q33*d63))/D;
    xx = k1;
    yy = (m1*zz^4 + m2*zz^3 + m3*zz^2 + m4*zz + m5)/(m6*zz^3 + m7*zz^2 + m8*zz + m9);
    
    u = (a4 + a3*zz + a2*zz^2 + (a1*(m1*zz^4 + m2*zz^3 + m3*zz^2 + m4*zz + m5))/(m6*zz^3 + m7*zz^2 + m8*zz + m9))/(a9 + a8*zz + a7*zz^2 + ((a6 + a5*zz)*(m1*zz^4 + m2*zz^3 + m3*zz^2 + m4*zz + m5))/(m6*zz^3 + m7*zz^2 + m8*zz + m9));
    k = -(a14 + a13*zz + a12*zz^2 + ((a11 + a10*zz)*(m1*zz^4 + m2*zz^3 + m3*zz^2 + m4*zz + m5))/(m6*zz^3 + m7*zz^2 + m8*zz + m9))/(a9 + a8*zz + a7*zz^2 + ((a6 + a5*zz)*(m1*zz^4 + m2*zz^3 + m3*zz^2 + m4*zz + m5))/(m6*zz^3 + m7*zz^2 + m8*zz + m9));
    
    hhh11 = 1/u; hhh12 = -k/u; 
    hhh21 = k/u; hhh22 = 1/u;  hhh24 = -(D*(k - s))/u;

     
    DD_ = ((d62*xx - d61*yy)^2 + (d63*xx - d61*zz)^2 + (d63*yy - d62*zz)^2)^(1/2);
    c11 = -(d63*yy - d62*zz)/DD_; c12 = (d63*xx - d61*zz)/DD_; c13 = -(d62*xx - d61*yy)/DD_;

    hhhh11 = d61^2 + c11*d81 - (c12*d63 - c13*d62)*(d62*d83 - d63*d82);
    hhhh12 = c11*d82 + d61*d62 + (c12*d63 - c13*d62)*(d61*d83 - d63*d81);
    hhhh13 = c11*d83 + d61*d63 - (c12*d63 - c13*d62)*(d61*d82 - d62*d81);
    hhhh21 =  c12*d81 + d61*d62 + (c11*d63 - c13*d61)*(d62*d83 - d63*d82);
    hhhh22 = d62^2 + c12*d82 - (c11*d63 - c13*d61)*(d61*d83 - d63*d81);
    hhhh23 = c12*d83 + d62*d63 + (c11*d63 - c13*d61)*(d61*d82 - d62*d81);
    hhhh31 = c13*d81 + d61*d63 - (c11*d62 - c12*d61)*(d62*d83 - d63*d82);
    hhhh32 = c13*d82 + d62*d63 + (c11*d62 - c12*d61)*(d61*d83 - d63*d81);
    hhhh33 = d63^2 + c13*d83 - (c11*d62 - c12*d61)*(d61*d82 - d62*d81);
       
    hs11 = hh11*(hhhh31*ih13 + hhhh11*(hhh11*ih11 + hhh21*ih12) + hhhh21*(hhh12*ih11 + hhh22*ih12)) + hh21*(hhhh32*ih13 + hhhh12*(hhh11*ih11 + hhh21*ih12) + hhhh22*(hhh12*ih11 + hhh22*ih12)) + hh31*(hhhh33*ih13 + hhhh13*(hhh11*ih11 + hhh21*ih12) + hhhh23*(hhh12*ih11 + hhh22*ih12));
    hs12 = hh12*(hhhh31*ih13 + hhhh11*(hhh11*ih11 + hhh21*ih12) + hhhh21*(hhh12*ih11 + hhh22*ih12)) + hh22*(hhhh32*ih13 + hhhh12*(hhh11*ih11 + hhh21*ih12) + hhhh22*(hhh12*ih11 + hhh22*ih12)) + hh32*(hhhh33*ih13 + hhhh13*(hhh11*ih11 + hhh21*ih12) + hhhh23*(hhh12*ih11 + hhh22*ih12));
    hs13 = hh13*(hhhh31*ih13 + hhhh11*(hhh11*ih11 + hhh21*ih12) + hhhh21*(hhh12*ih11 + hhh22*ih12)) + hh23*(hhhh32*ih13 + hhhh12*(hhh11*ih11 + hhh21*ih12) + hhhh22*(hhh12*ih11 + hhh22*ih12)) + hh33*(hhhh33*ih13 + hhhh13*(hhh11*ih11 + hhh21*ih12) + hhhh23*(hhh12*ih11 + hhh22*ih12));
    hs14 = ih14 + hhh24*ih12 + hh14*(hhhh31*ih13 + hhhh11*(hhh11*ih11 + hhh21*ih12) + hhhh21*(hhh12*ih11 + hhh22*ih12)) + hh24*(hhhh32*ih13 + hhhh12*(hhh11*ih11 + hhh21*ih12) + hhhh22*(hhh12*ih11 + hhh22*ih12)) + hh34*(hhhh33*ih13 + hhhh13*(hhh11*ih11 + hhh21*ih12) + hhhh23*(hhh12*ih11 + hhh22*ih12));

    hs21 = hh11*(hhhh31*ih23 + hhhh11*(hhh11*ih21 + hhh21*ih22) + hhhh21*(hhh12*ih21 + hhh22*ih22)) + hh21*(hhhh32*ih23 + hhhh12*(hhh11*ih21 + hhh21*ih22) + hhhh22*(hhh12*ih21 + hhh22*ih22)) + hh31*(hhhh33*ih23 + hhhh13*(hhh11*ih21 + hhh21*ih22) + hhhh23*(hhh12*ih21 + hhh22*ih22));
    hs22 = hh12*(hhhh31*ih23 + hhhh11*(hhh11*ih21 + hhh21*ih22) + hhhh21*(hhh12*ih21 + hhh22*ih22)) + hh22*(hhhh32*ih23 + hhhh12*(hhh11*ih21 + hhh21*ih22) + hhhh22*(hhh12*ih21 + hhh22*ih22)) + hh32*(hhhh33*ih23 + hhhh13*(hhh11*ih21 + hhh21*ih22) + hhhh23*(hhh12*ih21 + hhh22*ih22));
    hs23 = hh13*(hhhh31*ih23 + hhhh11*(hhh11*ih21 + hhh21*ih22) + hhhh21*(hhh12*ih21 + hhh22*ih22)) + hh23*(hhhh32*ih23 + hhhh12*(hhh11*ih21 + hhh21*ih22) + hhhh22*(hhh12*ih21 + hhh22*ih22)) + hh33*(hhhh33*ih23 + hhhh13*(hhh11*ih21 + hhh21*ih22) + hhhh23*(hhh12*ih21 + hhh22*ih22));
    hs24 = ih24 + hhh24*ih22 + hh14*(hhhh31*ih23 + hhhh11*(hhh11*ih21 + hhh21*ih22) + hhhh21*(hhh12*ih21 + hhh22*ih22)) + hh24*(hhhh32*ih23 + hhhh12*(hhh11*ih21 + hhh21*ih22) + hhhh22*(hhh12*ih21 + hhh22*ih22)) + hh34*(hhhh33*ih23 + hhhh13*(hhh11*ih21 + hhh21*ih22) + hhhh23*(hhh12*ih21 + hhh22*ih22));

    hs31 = hh11*(hhhh31*ih33 + hhhh11*(hhh11*ih31 + hhh21*ih32) + hhhh21*(hhh12*ih31 + hhh22*ih32)) + hh21*(hhhh32*ih33 + hhhh12*(hhh11*ih31 + hhh21*ih32) + hhhh22*(hhh12*ih31 + hhh22*ih32)) + hh31*(hhhh33*ih33 + hhhh13*(hhh11*ih31 + hhh21*ih32) + hhhh23*(hhh12*ih31 + hhh22*ih32));
    hs32 = hh12*(hhhh31*ih33 + hhhh11*(hhh11*ih31 + hhh21*ih32) + hhhh21*(hhh12*ih31 + hhh22*ih32)) + hh22*(hhhh32*ih33 + hhhh12*(hhh11*ih31 + hhh21*ih32) + hhhh22*(hhh12*ih31 + hhh22*ih32)) + hh32*(hhhh33*ih33 + hhhh13*(hhh11*ih31 + hhh21*ih32) + hhhh23*(hhh12*ih31 + hhh22*ih32));
    hs33 = hh13*(hhhh31*ih33 + hhhh11*(hhh11*ih31 + hhh21*ih32) + hhhh21*(hhh12*ih31 + hhh22*ih32)) + hh23*(hhhh32*ih33 + hhhh12*(hhh11*ih31 + hhh21*ih32) + hhhh22*(hhh12*ih31 + hhh22*ih32)) + hh33*(hhhh33*ih33 + hhhh13*(hhh11*ih31 + hhh21*ih32) + hhhh23*(hhh12*ih31 + hhh22*ih32));
    hs34 = ih34 + hhh24*ih32 + hh14*(hhhh31*ih33 + hhhh11*(hhh11*ih31 + hhh21*ih32) + hhhh21*(hhh12*ih31 + hhh22*ih32)) + hh24*(hhhh32*ih33 + hhhh12*(hhh11*ih31 + hhh21*ih32) + hhhh22*(hhh12*ih31 + hhh22*ih32)) + hh34*(hhhh33*ih33 + hhhh13*(hhh11*ih31 + hhh21*ih32) + hhhh23*(hhh12*ih31 + hhh22*ih32));

    Hs = [hs11, hs12, hs13, hs14; hs21, hs22, hs23, hs24; hs31, hs32, hs33, hs34; 0, 0, 0, 1];
    
%     NRs = [NRs Hs(1:3,1:3)];
%     NTs = [NTs Hs(1:3,4)];

    NRs(:,((i-1)*3+1):i*3) = Hs(1:3,1:3);
    NTs(:,i) = Hs(1:3,4);

    
end

Computation_Time = toc(tic_Time_ALL);
if ~isempty(NTs), NNumSol = numel(NTs(1,:)); end


end

