%% A Robust Parameterization for the General Minimal Pose Problem
% Author: Pedro Miraldo (miraldo@isr.uc.pt)
% Institution: Institute for Systems and Robotics, University of Coimbra
function [Rs, Ts, NumSol, Time_ALL] = pose_problem_CHEN_CHANG(Point_Line)

NumSol = [];

%% additional computations that we do not count for the computation time

d1 = Point_Line(1,4:6)'; d1 = d1/norm(d1);
d2 = Point_Line(2,4:6)'; d2 = d2/norm(d2);
d3 = Point_Line(3,4:6)'; d3 = d3/norm(d3);

p1 = Point_Line(1,7:9)';p2 = Point_Line(2,7:9)';p3 = Point_Line(3,7:9)';
m1 = cross(p1,d1); m2 = cross(p2,d2); m3 = cross(p3,d3);
q1 = Point_Line(1,1:3)'; q2 = Point_Line(2,1:3)'; q3 = Point_Line(3,1:3)';


%% Start the pose problem
tic_time_ALL = tic;

z11 = q1(1); z12 = q1(2); z13 = q1(3);
z21 = q2(1); z22 = q2(2); z23 = q2(3);
z31 = q3(1); z32 = q3(2); z33 = q3(3);

d11_ = d1(1); d12_ = d1(2); d13_ = d1(3);
d21_ = d2(1); d22_ = d2(2); d23_ = d2(3);
d31_ = d3(1); d32_ = d3(2); d33_ = d3(3);

a = ((z11-z21)*(z11-z21) + (z12-z22)*(z12-z22) + (z13-z23)*(z13-z23))^(1/2);
b = ((z11-z31)*(z11-z31) + (z12-z32)*(z12-z32) + (z13-z33)*(z13-z33))^(1/2);
c = ((z21-z31)*(z21-z31) + (z22-z32)*(z22-z32) + (z23-z33)*(z23-z33))^(1/2);

%% predefined transformation

a11 = d1(1); a12 = d1(2); a13 = d1(3);
a21 = d2(1); a22 = d2(2); a23 = d2(3);
a31 = d3(1); a32 = d3(2); a33 = d3(3);

c11 = m1(1); c12 = m1(2); c13 = m1(3);
c21 = m2(1); c22 = m2(2); c23 = m2(3);
c31 = m3(1); c32 = m3(2); c33 = m3(3);

aux1 = ((a11*a22 - a12*a21)^2 + (a11*a23 - a13*a21)^2 + (a12*a23 - a13*a22)^2)^(1/2);
aux2 = ((a11*a32 - a12*a31)^2 + (a11*a33 - a13*a31)^2 + (a12*a33 - a13*a32)^2)^(1/2);
aux3 = ((a21*a32 - a22*a31)^2 + (a21*a33 - a23*a31)^2 + (a22*a33 - a23*a32)^2)^(1/2);

aa11_ =  (a12*a23 - a13*a22)/aux1;
aa12_ = -(a11*a23 - a13*a21)/aux1;
aa13_ =  (a11*a22 - a12*a21)/aux1;
aa11 = aa11_; aa12 = aa12_; aa13 = aa13_;

aa21_ =  (a12*a33 - a13*a32)/aux2;
aa22_ = -(a11*a33 - a13*a31)/aux2;
aa23_ =  (a11*a32 - a12*a31)/aux2;
aa21 = aa21_; aa22 = aa22_; aa23 = aa23_;

aa31_ =  (a22*a33 - a23*a32)/aux3;
aa32_ = -(a21*a33 - a23*a31)/aux3;
aa33_ =  (a21*a32 - a22*a31)/aux3;
aa31 = aa31_; aa32 = aa32_; aa33 = aa33_;

bb11_ = -(a13*aa12^2*c22 - a23*aa12^2*c12 - a12*aa13^2*c23 + a22*aa13^2*c13 - a12*aa11*aa13*c21 + a13*aa11*aa12*c21 + a22*aa11*aa13*c11 - a23*aa11*aa12*c11 - a12*aa12*aa13*c22 + a22*aa12*aa13*c12 + a13*aa12*aa13*c23 - a23*aa12*aa13*c13)/(a11*a22*aa13 - a11*a23*aa12 - a12*a21*aa13 + a12*a23*aa11 + a13*a21*aa12 - a13*a22*aa11);
bb12_ =  (a13*aa11^2*c21 - a23*aa11^2*c11 - a11*aa13^2*c23 + a21*aa13^2*c13 - a11*aa11*aa13*c21 + a21*aa11*aa13*c11 - a11*aa12*aa13*c22 + a13*aa11*aa12*c22 + a21*aa12*aa13*c12 - a23*aa11*aa12*c12 + a13*aa11*aa13*c23 - a23*aa11*aa13*c13)/(a11*a22*aa13 - a11*a23*aa12 - a12*a21*aa13 + a12*a23*aa11 + a13*a21*aa12 - a13*a22*aa11);
bb13_ = -(a12*aa11^2*c21 - a22*aa11^2*c11 - a11*aa12^2*c22 + a21*aa12^2*c12 - a11*aa11*aa12*c21 + a21*aa11*aa12*c11 + a12*aa11*aa12*c22 - a22*aa11*aa12*c12 - a11*aa12*aa13*c23 + a12*aa11*aa13*c23 + a21*aa12*aa13*c13 - a22*aa11*aa13*c13)/(a11*a22*aa13 - a11*a23*aa12 - a12*a21*aa13 + a12*a23*aa11 + a13*a21*aa12 - a13*a22*aa11);
bb11 = bb11_; bb12 = bb12_; bb13 = bb13_;

bb21_ = -(a13*aa22^2*c32 - a33*aa22^2*c12 - a12*aa23^2*c33 + a32*aa23^2*c13 - a12*aa21*aa23*c31 + a13*aa21*aa22*c31 + a32*aa21*aa23*c11 - a33*aa21*aa22*c11 - a12*aa22*aa23*c32 + a32*aa22*aa23*c12 + a13*aa22*aa23*c33 - a33*aa22*aa23*c13)/(a11*a32*aa23 - a11*a33*aa22 - a12*a31*aa23 + a12*a33*aa21 + a13*a31*aa22 - a13*a32*aa21);
bb22_ =  (a13*aa21^2*c31 - a33*aa21^2*c11 - a11*aa23^2*c33 + a31*aa23^2*c13 - a11*aa21*aa23*c31 + a31*aa21*aa23*c11 - a11*aa22*aa23*c32 + a13*aa21*aa22*c32 + a31*aa22*aa23*c12 - a33*aa21*aa22*c12 + a13*aa21*aa23*c33 - a33*aa21*aa23*c13)/(a11*a32*aa23 - a11*a33*aa22 - a12*a31*aa23 + a12*a33*aa21 + a13*a31*aa22 - a13*a32*aa21);
bb23_ = -(a12*aa21^2*c31 - a32*aa21^2*c11 - a11*aa22^2*c32 + a31*aa22^2*c12 - a11*aa21*aa22*c31 + a31*aa21*aa22*c11 + a12*aa21*aa22*c32 - a32*aa21*aa22*c12 - a11*aa22*aa23*c33 + a12*aa21*aa23*c33 + a31*aa22*aa23*c13 - a32*aa21*aa23*c13)/(a11*a32*aa23 - a11*a33*aa22 - a12*a31*aa23 + a12*a33*aa21 + a13*a31*aa22 - a13*a32*aa21);
bb21 = bb21_; bb22 = bb22_; bb23 = bb23_;

bb31_ = -(a23*aa32^2*c32 - a33*aa32^2*c22 - a22*aa33^2*c33 + a32*aa33^2*c23 - a22*aa31*aa33*c31 + a23*aa31*aa32*c31 + a32*aa31*aa33*c21 - a33*aa31*aa32*c21 - a22*aa32*aa33*c32 + a32*aa32*aa33*c22 + a23*aa32*aa33*c33 - a33*aa32*aa33*c23)/(a21*a32*aa33 - a21*a33*aa32 - a22*a31*aa33 + a22*a33*aa31 + a23*a31*aa32 - a23*a32*aa31);
bb32_ =  (a23*aa31^2*c31 - a33*aa31^2*c21 - a21*aa33^2*c33 + a31*aa33^2*c23 - a21*aa31*aa33*c31 + a31*aa31*aa33*c21 - a21*aa32*aa33*c32 + a23*aa31*aa32*c32 + a31*aa32*aa33*c22 - a33*aa31*aa32*c22 + a23*aa31*aa33*c33 - a33*aa31*aa33*c23)/(a21*a32*aa33 - a21*a33*aa32 - a22*a31*aa33 + a22*a33*aa31 + a23*a31*aa32 - a23*a32*aa31);
bb33_ = -(a22*aa31^2*c31 - a32*aa31^2*c21 - a21*aa32^2*c32 + a31*aa32^2*c22 - a21*aa31*aa32*c31 + a31*aa31*aa32*c21 + a22*aa31*aa32*c32 - a32*aa31*aa32*c22 - a21*aa32*aa33*c33 + a22*aa31*aa33*c33 + a31*aa32*aa33*c23 - a32*aa31*aa33*c23)/(a21*a32*aa33 - a21*a33*aa32 - a22*a31*aa33 + a22*a33*aa31 + a23*a31*aa32 - a23*a32*aa31);
bb31 = bb31_; bb32 = bb32_; bb33 = bb33_;

aux4 = (aa11*c11 + aa12*c12 + aa13*c13);
aux5 = (aa11*c21 + aa12*c22 + aa13*c23);
aux6 = (aa21*c31 + aa22*c32 + aa23*c33);

cc121_ = -(bb12*c13 - bb13*c12)/aux4;
cc122_ =  (bb11*c13 - bb13*c11)/aux4;
cc123_ = -(bb11*c12 - bb12*c11)/aux4;

cc211_ = -(bb12*c23 - bb13*c22)/aux5;
cc212_ =  (bb11*c23 - bb13*c21)/aux5;
cc213_ = -(bb11*c22 - bb12*c21)/aux5;

cc311_ = -(bb22*c33 - bb23*c32)/aux6;
cc312_ =  (bb21*c33 - bb23*c31)/aux6;
cc313_ = -(bb21*c32 - bb22*c31)/aux6;

cc11 = 0; cc12 = 0; cc13 = 0;

cc21 = (aa13*(bb11*c12 - bb12*c11))/aux4 - (aa12*(bb11*c13 - bb13*c11))/aux4 + (aa11*(bb12*c13 - bb13*c12))/aux4 - (aa13*(bb11*c22 - bb12*c21))/aux5 + (aa12*(bb11*c23 - bb13*c21))/aux5 - (aa11*(bb12*c23 - bb13*c22))/aux5;
cc22 = (a13*(bb11*c12 - bb12*c11))/aux4 - (a12*(bb11*c13 - bb13*c11))/aux4 + (a11*(bb12*c13 - bb13*c12))/aux4 - (a13*(bb11*c22 - bb12*c21))/aux5 + (a12*(bb11*c23 - bb13*c21))/aux5 - (a11*(bb12*c23 - bb13*c22))/aux5;
cc23 = ((a11*aa12 - a12*aa11)*(bb11*c22 - bb12*c21))/aux5 - ((a11*aa13 - a13*aa11)*(bb11*c13 - bb13*c11))/aux4 - ((a12*aa13 - a13*aa12)*(bb12*c13 - bb13*c12))/aux4 - ((a11*aa12 - a12*aa11)*(bb11*c12 - bb12*c11))/aux4 + ((a11*aa13 - a13*aa11)*(bb11*c23 - bb13*c21))/aux5 + ((a12*aa13 - a13*aa12)*(bb12*c23 - bb13*c22))/aux5;

cc31 = (aa13*(bb11*c12 - bb12*c11))/aux4 - (aa12*(bb11*c13 - bb13*c11))/aux4 + (aa11*(bb12*c13 - bb13*c12))/aux4 - (aa13*(bb21*c12 - bb22*c11))/(aa21*c11 + aa22*c12 + aa23*c13) + (aa12*(bb21*c13 - bb23*c11))/(aa21*c11 + aa22*c12 + aa23*c13) - (aa11*(bb22*c13 - bb23*c12))/(aa21*c11 + aa22*c12 + aa23*c13);
cc32 = (a13*(bb11*c12 - bb12*c11))/aux4 - (a12*(bb11*c13 - bb13*c11))/aux4 + (a11*(bb12*c13 - bb13*c12))/aux4 - (a13*(bb21*c12 - bb22*c11))/(aa21*c11 + aa22*c12 + aa23*c13) + (a12*(bb21*c13 - bb23*c11))/(aa21*c11 + aa22*c12 + aa23*c13) - (a11*(bb22*c13 - bb23*c12))/(aa21*c11 + aa22*c12 + aa23*c13);
cc33 = ((a11*aa12 - a12*aa11)*(bb21*c12 - bb22*c11))/(aa21*c11 + aa22*c12 + aa23*c13) - ((a11*aa13 - a13*aa11)*(bb11*c13 - bb13*c11))/aux4 - ((a12*aa13 - a13*aa12)*(bb12*c13 - bb13*c12))/aux4 - ((a11*aa12 - a12*aa11)*(bb11*c12 - bb12*c11))/aux4 + ((a11*aa13 - a13*aa11)*(bb21*c13 - bb23*c11))/(aa21*c11 + aa22*c12 + aa23*c13) + ((a12*aa13 - a13*aa12)*(bb22*c13 - bb23*c12))/(aa21*c11 + aa22*c12 + aa23*c13);

cc41 = (aa13*(bb11*c12 - bb12*c11))/aux4 - (aa12*(bb11*c13 - bb13*c11))/aux4 + (aa11*(bb12*c13 - bb13*c12))/aux4 - (aa13*(bb21*c32 - bb22*c31))/aux6 + (aa12*(bb21*c33 - bb23*c31))/aux6 - (aa11*(bb22*c33 - bb23*c32))/aux6;
cc42 = (a13*(bb11*c12 - bb12*c11))/aux4 - (a12*(bb11*c13 - bb13*c11))/aux4 + (a11*(bb12*c13 - bb13*c12))/aux4 - (a13*(bb21*c32 - bb22*c31))/aux6 + (a12*(bb21*c33 - bb23*c31))/aux6 - (a11*(bb22*c33 - bb23*c32))/aux6;
cc43 = ((a11*aa12 - a12*aa11)*(bb21*c32 - bb22*c31))/aux6 - ((a11*aa13 - a13*aa11)*(bb11*c13 - bb13*c11))/aux4 - ((a12*aa13 - a13*aa12)*(bb12*c13 - bb13*c12))/aux4 - ((a11*aa12 - a12*aa11)*(bb11*c12 - bb12*c11))/aux4 + ((a11*aa13 - a13*aa11)*(bb21*c33 - bb23*c31))/aux6 + ((a12*aa13 - a13*aa12)*(bb22*c33 - bb23*c32))/aux6;

cc51 = (aa13*(bb11*c12 - bb12*c11))/aux4 - (aa12*(bb11*c13 - bb13*c11))/aux4 + (aa11*(bb12*c13 - bb13*c12))/aux4 - (aa13*(bb31*c22 - bb32*c21))/(aa31*c21 + aa32*c22 + aa33*c23) + (aa12*(bb31*c23 - bb33*c21))/(aa31*c21 + aa32*c22 + aa33*c23) - (aa11*(bb32*c23 - bb33*c22))/(aa31*c21 + aa32*c22 + aa33*c23);
cc52 = (a13*(bb11*c12 - bb12*c11))/aux4 - (a12*(bb11*c13 - bb13*c11))/aux4 + (a11*(bb12*c13 - bb13*c12))/aux4 - (a13*(bb31*c22 - bb32*c21))/(aa31*c21 + aa32*c22 + aa33*c23) + (a12*(bb31*c23 - bb33*c21))/(aa31*c21 + aa32*c22 + aa33*c23) - (a11*(bb32*c23 - bb33*c22))/(aa31*c21 + aa32*c22 + aa33*c23);
cc53 = ((a11*aa12 - a12*aa11)*(bb31*c22 - bb32*c21))/(aa31*c21 + aa32*c22 + aa33*c23) - ((a11*aa13 - a13*aa11)*(bb11*c13 - bb13*c11))/aux4 - ((a12*aa13 - a13*aa12)*(bb12*c13 - bb13*c12))/aux4 - ((a11*aa12 - a12*aa11)*(bb11*c12 - bb12*c11))/aux4 + ((a11*aa13 - a13*aa11)*(bb31*c23 - bb33*c21))/(aa31*c21 + aa32*c22 + aa33*c23) + ((a12*aa13 - a13*aa12)*(bb32*c23 - bb33*c22))/(aa31*c21 + aa32*c22 + aa33*c23);

cc61 = (aa13*(bb11*c12 - bb12*c11))/aux4 - (aa12*(bb11*c13 - bb13*c11))/aux4 + (aa11*(bb12*c13 - bb13*c12))/aux4 - (aa13*(bb31*c32 - bb32*c31))/(aa31*c31 + aa32*c32 + aa33*c33) + (aa12*(bb31*c33 - bb33*c31))/(aa31*c31 + aa32*c32 + aa33*c33) - (aa11*(bb32*c33 - bb33*c32))/(aa31*c31 + aa32*c32 + aa33*c33);
cc62 = (a13*(bb11*c12 - bb12*c11))/aux4 - (a12*(bb11*c13 - bb13*c11))/aux4 + (a11*(bb12*c13 - bb13*c12))/aux4 - (a13*(bb31*c32 - bb32*c31))/(aa31*c31 + aa32*c32 + aa33*c33) + (a12*(bb31*c33 - bb33*c31))/(aa31*c31 + aa32*c32 + aa33*c33) - (a11*(bb32*c33 - bb33*c32))/(aa31*c31 + aa32*c32 + aa33*c33);
cc63 = ((a11*aa12 - a12*aa11)*(bb31*c32 - bb32*c31))/(aa31*c31 + aa32*c32 + aa33*c33) - ((a11*aa13 - a13*aa11)*(bb11*c13 - bb13*c11))/aux4 - ((a12*aa13 - a13*aa12)*(bb12*c13 - bb13*c12))/aux4 - ((a11*aa12 - a12*aa11)*(bb11*c12 - bb12*c11))/aux4 + ((a11*aa13 - a13*aa11)*(bb31*c33 - bb33*c31))/(aa31*c31 + aa32*c32 + aa33*c33) + ((a12*aa13 - a13*aa12)*(bb32*c33 - bb33*c32))/(aa31*c31 + aa32*c32 + aa33*c33);

dd1 = ((cc11 - cc31)^2 + (cc12 - cc32)^2 + (cc13 - cc33)^2)^(1/2)*(-sign((cc12 - cc32)*(a11^2 + a12^2 + a13^2) - (cc13 - cc33)*(a13*(a11*aa12 - a12*aa11) - a12*(a11*aa13 - a13*aa11) + a11*(a12*aa13 - a13*aa12)) + (cc11 - cc31)*(a11*aa11 + a12*aa12 + a13*aa13)));
dd2 = ((cc21 - cc51)^2 + (cc22 - cc52)^2 + (cc23 - cc53)^2)^(1/2)*(-sign((cc22 - cc52)*(a11*a21 + a12*a22 + a13*a23) - (cc23 - cc53)*(a23*(a11*aa12 - a12*aa11) - a22*(a11*aa13 - a13*aa11) + a21*(a12*aa13 - a13*aa12)) + (cc21 - cc51)*(a21*aa11 + a22*aa12 + a23*aa13)));
dd3 = ((cc41 - cc61)^2 + (cc42 - cc62)^2 + (cc43 - cc63)^2)^(1/2)*(-sign((cc42 - cc62)*(a11*a31 + a12*a32 + a13*a33) - (cc43 - cc63)*(a33*(a11*aa12 - a12*aa11) - a32*(a11*aa13 - a13*aa11) + a31*(a12*aa13 - a13*aa12)) + (cc41 - cc61)*(a31*aa11 + a32*aa12 + a33*aa13)));

dd12 = ((cc11 - cc21)^2 + (cc12 - cc22)^2 + (cc13 - cc23)^2)^(1/2);
dd13 = ((cc31 - cc41)^2 + (cc32 - cc42)^2 + (cc33 - cc43)^2)^(1/2);
dd23 = ((cc51 - cc61)^2 + (cc52 - cc62)^2 + (cc53 - cc63)^2)^(1/2);

aux8  = (a11*aa12 - a12*aa11);
aux9  = (a11*aa13 - a13*aa11);
aux10 = (a12*aa13 - a13*aa12);
aux11 = (a11*aa11 + a12*aa12 + a13*aa13);

theta12 = atan2((((a13*aux8 - a12*aux9 + a11*aux10)*(a21*aa11 + a22*aa12 + a23*aa13) - (a23*aux8 - a22*aux9 + a21*aux10)*aux11)^2 + ((a11^2 + a12^2 + a13^2)*(a21*aa11 + a22*aa12 + a23*aa13) - (a11*a21 + a12*a22 + a13*a23)*aux11)^2 + ((a23*aux8 - a22*aux9 + a21*aux10)*(a11^2 + a12^2 + a13^2) - (a13*aux8 - a12*aux9 + a11*aux10)*(a11*a21 + a12*a22 + a13*a23))^2)^(1/2),(a13*aux8 - a12*aux9 + a11*aux10)*(a23*aux8 - a22*aux9 + a21*aux10) + (a11^2 + a12^2 + a13^2)*(a11*a21 + a12*a22 + a13*a23) + aux11*(a21*aa11 + a22*aa12 + a23*aa13));
theta13 = atan2((((a13*aux8 - a12*aux9 + a11*aux10)*(a31*aa11 + a32*aa12 + a33*aa13) - (a33*aux8 - a32*aux9 + a31*aux10)*aux11)^2 + ((a11^2 + a12^2 + a13^2)*(a31*aa11 + a32*aa12 + a33*aa13) - (a11*a31 + a12*a32 + a13*a33)*aux11)^2 + ((a33*aux8 - a32*aux9 + a31*aux10)*(a11^2 + a12^2 + a13^2) - (a13*aux8 - a12*aux9 + a11*aux10)*(a11*a31 + a12*a32 + a13*a33))^2)^(1/2),(a13*aux8 - a12*aux9 + a11*aux10)*(a33*aux8 - a32*aux9 + a31*aux10) + (a11^2 + a12^2 + a13^2)*(a11*a31 + a12*a32 + a13*a33) + aux11*(a31*aa11 + a32*aa12 + a33*aa13));
theta23 = atan2((((a23*aux8 - a22*aux9 + a21*aux10)*(a11*a31 + a12*a32 + a13*a33) - (a33*aux8 - a32*aux9 + a31*aux10)*(a11*a21 + a12*a22 + a13*a23))^2 + ((a23*aux8 - a22*aux9 + a21*aux10)*(a31*aa11 + a32*aa12 + a33*aa13) - (a33*aux8 - a32*aux9 + a31*aux10)*(a21*aa11 + a22*aa12 + a23*aa13))^2 + ((a11*a21 + a12*a22 + a13*a23)*(a31*aa11 + a32*aa12 + a33*aa13) - (a11*a31 + a12*a32 + a13*a33)*(a21*aa11 + a22*aa12 + a23*aa13))^2)^(1/2),(a23*aux8 - a22*aux9 + a21*aux10)*(a33*aux8 - a32*aux9 + a31*aux10) + (a11*a21 + a12*a22 + a13*a23)*(a11*a31 + a12*a32 + a13*a33) + (a21*aa11 + a22*aa12 + a23*aa13)*(a31*aa11 + a32*aa12 + a33*aa13));

%% Polynomial coefficients
% coeffs for A1
a1 = 2*cos(theta12) - 2*cos(theta13)*cos(theta23);
a2 = 2*dd3*cos(theta23) - 2*dd2 + 2*dd1*cos(theta13)*cos(theta23);
% coeffs for B1
a3 = 2*cos(theta12)*cos(theta23) - 2*cos(theta13);
a4 = 2*dd3 + 2*dd1*cos(theta13) - 2*dd2*cos(theta23);
% coeffs for C2
a5 = -sin(theta13)^2;
a6 = 2*dd1*sin(theta13)^2;
a7 = b^2 - dd1^2*sin(theta13)^2 - dd13^2;
% coeffs for B2
a8 = -sin(theta12)^2;
a9 = a^2 - dd12^2;
% coeffs for A2
a10 = cos(theta12)^2 + cos(theta13)^2 - sin(theta12)^2 - sin(theta13)^2 - 2*cos(theta12)*cos(theta13)*cos(theta23);
a11 = 2*dd1*sin(theta13)^2 - 2*dd2*cos(theta12) - 2*dd3*cos(theta13) - 2*dd1*cos(theta13)^2 + 2*dd2*cos(theta13)*cos(theta23) + 2*dd3*cos(theta12)*cos(theta23) + 2*dd1*cos(theta12)*cos(theta13)*cos(theta23);
a12 = dd1^2*cos(theta13)^2 - dd1^2*sin(theta13)^2 + a^2 + b^2 - c^2 + dd2^2 + dd3^2 - dd12^2 - dd13^2 + dd23^2 + 2*dd1*dd3*cos(theta13) - 2*dd2*dd3*cos(theta23) - 2*dd1*dd2*cos(theta13)*cos(theta23);
% coefficient for the eighth degree polynomial auqation

c1 = (a2^2*a9 - a4^2*a7 + a12^2 - 4*a7*a9*cos(theta23)^2)^2 - a9*(2*a2*a12 - 4*a4*a7*cos(theta23))^2;
c2 = - 2*(a2^2*a9 - a4^2*a7 + a12^2 - 4*a7*a9*cos(theta23)^2)*(a4^2*a6 - 2*a11*a12 + 4*a6*a9*cos(theta23)^2 - 2*a1*a2*a9 + 2*a3*a4*a7) - 2*a9*(2*a2*a12 - 4*a4*a7*cos(theta23))*(2*a1*a12 + 2*a2*a11 - 4*a3*a7*cos(theta23) - 4*a4*a6*cos(theta23));
c3 = (a4^2*a6 - 2*a11*a12 + 4*a6*a9*cos(theta23)^2 - 2*a1*a2*a9 + 2*a3*a4*a7)^2 - a8*(2*a2*a12 - 4*a4*a7*cos(theta23))^2 - 2*(a2^2*a9 - a4^2*a7 + a12^2 - 4*a7*a9*cos(theta23)^2)*(a4^2*a5 - 2*a10*a12 - a1^2*a9 - a2^2*a8 + a3^2*a7 - a11^2 + 4*a5*a9*cos(theta23)^2 + 4*a7*a8*cos(theta23)^2 + 2*a3*a4*a6) - a9*(2*(2*a2*a12 - 4*a4*a7*cos(theta23))*(2*a1*a11 + 2*a2*a10 - 4*a3*a6*cos(theta23) - 4*a4*a5*cos(theta23)) + (2*a1*a12 + 2*a2*a11 - 4*a3*a7*cos(theta23) - 4*a4*a6*cos(theta23))^2);
c4 = 2*(a4^2*a6 - 2*a11*a12 + 4*a6*a9*cos(theta23)^2 - 2*a1*a2*a9 + 2*a3*a4*a7)*(a4^2*a5 - 2*a10*a12 - a1^2*a9 - a2^2*a8 + a3^2*a7 - a11^2 + 4*a5*a9*cos(theta23)^2 + 4*a7*a8*cos(theta23)^2 + 2*a3*a4*a6) - 2*(a2^2*a9 - a4^2*a7 + a12^2 - 4*a7*a9*cos(theta23)^2)*(a3^2*a6 - 2*a10*a11 + 4*a6*a8*cos(theta23)^2 - 2*a1*a2*a8 + 2*a3*a4*a5) - a9*(2*(2*a1*a10 - 4*a3*a5*cos(theta23))*(2*a2*a12 - 4*a4*a7*cos(theta23)) + 2*(2*a1*a11 + 2*a2*a10 - 4*a3*a6*cos(theta23) - 4*a4*a5*cos(theta23))*(2*a1*a12 + 2*a2*a11 - 4*a3*a7*cos(theta23) - 4*a4*a6*cos(theta23))) - 2*a8*(2*a2*a12 - 4*a4*a7*cos(theta23))*(2*a1*a12 + 2*a2*a11 - 4*a3*a7*cos(theta23) - 4*a4*a6*cos(theta23));
c5 = 2*(a3^2*a6 - 2*a10*a11 + 4*a6*a8*cos(theta23)^2 - 2*a1*a2*a8 + 2*a3*a4*a5)*(a4^2*a6 - 2*a11*a12 + 4*a6*a9*cos(theta23)^2 - 2*a1*a2*a9 + 2*a3*a4*a7) + (a4^2*a5 - 2*a10*a12 - a1^2*a9 - a2^2*a8 + a3^2*a7 - a11^2 + 4*a5*a9*cos(theta23)^2 + 4*a7*a8*cos(theta23)^2 + 2*a3*a4*a6)^2 - a9*(2*(2*a1*a10 - 4*a3*a5*cos(theta23))*(2*a1*a12 + 2*a2*a11 - 4*a3*a7*cos(theta23) - 4*a4*a6*cos(theta23)) + (2*a1*a11 + 2*a2*a10 - 4*a3*a6*cos(theta23) - 4*a4*a5*cos(theta23))^2) - a8*(2*(2*a2*a12 - 4*a4*a7*cos(theta23))*(2*a1*a11 + 2*a2*a10 - 4*a3*a6*cos(theta23) - 4*a4*a5*cos(theta23)) + (2*a1*a12 + 2*a2*a11 - 4*a3*a7*cos(theta23) - 4*a4*a6*cos(theta23))^2) - 2*(a2^2*a9 - a4^2*a7 + a12^2 - 4*a7*a9*cos(theta23)^2)*(a3^2*a5 - a1^2*a8 - a10^2 + 4*a5*a8*cos(theta23)^2);
c6 = 2*(a3^2*a6 - 2*a10*a11 + 4*a6*a8*cos(theta23)^2 - 2*a1*a2*a8 + 2*a3*a4*a5)*(a4^2*a5 - 2*a10*a12 - a1^2*a9 - a2^2*a8 + a3^2*a7 - a11^2 + 4*a5*a9*cos(theta23)^2 + 4*a7*a8*cos(theta23)^2 + 2*a3*a4*a6) + 2*(a3^2*a5 - a1^2*a8 - a10^2 + 4*a5*a8*cos(theta23)^2)*(a4^2*a6 - 2*a11*a12 + 4*a6*a9*cos(theta23)^2 - 2*a1*a2*a9 + 2*a3*a4*a7) - a8*(2*(2*a1*a10 - 4*a3*a5*cos(theta23))*(2*a2*a12 - 4*a4*a7*cos(theta23)) + 2*(2*a1*a11 + 2*a2*a10 - 4*a3*a6*cos(theta23) - 4*a4*a5*cos(theta23))*(2*a1*a12 + 2*a2*a11 - 4*a3*a7*cos(theta23) - 4*a4*a6*cos(theta23))) - 2*a9*(2*a1*a10 - 4*a3*a5*cos(theta23))*(2*a1*a11 + 2*a2*a10 - 4*a3*a6*cos(theta23) - 4*a4*a5*cos(theta23));
c7 = 2*(a3^2*a5 - a1^2*a8 - a10^2 + 4*a5*a8*cos(theta23)^2)*(a4^2*a5 - 2*a10*a12 - a1^2*a9 - a2^2*a8 + a3^2*a7 - a11^2 + 4*a5*a9*cos(theta23)^2 + 4*a7*a8*cos(theta23)^2 + 2*a3*a4*a6) - a8*(2*(2*a1*a10 - 4*a3*a5*cos(theta23))*(2*a1*a12 + 2*a2*a11 - 4*a3*a7*cos(theta23) - 4*a4*a6*cos(theta23)) + (2*a1*a11 + 2*a2*a10 - 4*a3*a6*cos(theta23) - 4*a4*a5*cos(theta23))^2) - a9*(2*a1*a10 - 4*a3*a5*cos(theta23))^2 + (a3^2*a6 - 2*a10*a11 + 4*a6*a8*cos(theta23)^2 - 2*a1*a2*a8 + 2*a3*a4*a5)^2;
c8 = 2*(a3^2*a5 - a1^2*a8 - a10^2 + 4*a5*a8*cos(theta23)^2)*(a3^2*a6 - 2*a10*a11 + 4*a6*a8*cos(theta23)^2 - 2*a1*a2*a8 + 2*a3*a4*a5) - 2*a8*(2*a1*a10 - 4*a3*a5*cos(theta23))*(2*a1*a11 + 2*a2*a10 - 4*a3*a6*cos(theta23) - 4*a4*a5*cos(theta23));
c9 = (a3^2*a5 - a1^2*a8 - a10^2 + 4*a5*a8*cos(theta23)^2)^2 - a8*(2*a1*a10 - 4*a3*a5*cos(theta23))^2;

%% compute the roots
M = [-c8/c9, -c7/c9, -c6/c9, -c5/c9, -c4/c9, -c3/c9, -c2/c9, -c1/c9 ;eye(7) zeros(7,1)];
% isinf(M(1,2))

if ~isinf(M(1,2))
    
    [~,sz] = eig(M);
    sz = diag(sz);
    % remove the imaginary solutions
    st1 = sz(sz == real(sz));
    
    Numhyp = numel(st1);
    
    %% Recover the pose
    Rs = zeros(3,3*Numhyp);
    Ts = zeros(3,Numhyp);
    for i=1:Numhyp
        
        t1 = st1(i);
        
        ta21 = t1*cos(theta12) + ( a^2 - dd12^2 - t1^2*(sin(theta12))^2)^(1/2);
        ta31 = (t1 - dd1)*cos(theta13) + (b^2 - dd13^2 - (t1 - dd1)^2 * sin(theta13)^2)^(1/2);
        
        ta22 = t1*cos(theta12) - ( a^2 - dd12^2 - t1^2*(sin(theta12))^2)^(1/2);
        ta32 = (t1 - dd1)*cos(theta13) + (b^2 - dd13^2 - (t1 - dd1)^2 * sin(theta13)^2)^(1/2);
        
        ta23 = t1*cos(theta12) + ( a^2 - dd12^2 - t1^2*(sin(theta12))^2)^(1/2);
        ta33 = (t1 - dd1)*cos(theta13) - (b^2 - dd13^2 - (t1 - dd1)^2 * sin(theta13)^2)^(1/2);
        
        ta24 = t1*cos(theta12) - ( a^2 - dd12^2 - t1^2*(sin(theta12))^2)^(1/2);
        ta34 = (t1 - dd1)*cos(theta13) - (b^2 - dd13^2 - (t1 - dd1)^2 * sin(theta13)^2)^(1/2);
        
        val1 = abs((ta31 - dd3)^2 - 2*(ta31 - dd3)*(ta21 - dd2)*cos(theta23) + (ta21 - dd2)^2 - (c^2 - dd23^2));
        val2 = abs((ta32 - dd3)^2 - 2*(ta32 - dd3)*(ta22 - dd2)*cos(theta23) + (ta22 - dd2)^2 - (c^2 - dd23^2));
        val3 = abs((ta33 - dd3)^2 - 2*(ta33 - dd3)*(ta23 - dd2)*cos(theta23) + (ta23 - dd2)^2 - (c^2 - dd23^2));
        val4 = abs((ta34 - dd3)^2 - 2*(ta34 - dd3)*(ta24 - dd2)*cos(theta23) + (ta24 - dd2)^2 - (c^2 - dd23^2));
        
        [~,I] = min([val1 val2 val3 val4]);
        
        if     I==1, t2 = ta21; t3 = ta31;
        elseif I==2, t2 = ta22; t3 = ta32;
        elseif I==3, t2 = ta23; t3 = ta33;
        else         t2 = ta24; t3 = ta34;
        end
        
        ql11 = cc121_+t1*d11_; ql12 = cc122_+t1*d12_; ql13 = cc123_+t1*d13_;
        ql21 = cc211_+t2*d21_; ql22 = cc212_+t2*d22_; ql23 = cc213_+t2*d23_;
        ql31 = cc311_+t3*d31_; ql32 = cc312_+t3*d32_; ql33 = cc313_+t3*d33_;
        
        qbar1 = (1/3)*(z11+z21+z31); qbar2 = (1/3)*(z12+z22+z32); qbar3 = (1/3)*(z13+z23+z33);
        
        pc11 = qbar1 - z11; pc12 = qbar2 - z12; pc13 = qbar3 - z13;
        pc21 = qbar1 - z21; pc22 = qbar2 - z22; pc23 = qbar3 - z23;
        pc31 = qbar1 - z31; pc32 = qbar2 - z32; pc33 = qbar3 - z33;
        
        qlbar1 = (1/3)*(ql11+ql21+ql31);
        qlbar2 = (1/3)*(ql12+ql22+ql32);
        qlbar3 = (1/3)*(ql13+ql23+ql33);
        
        plc11 = qlbar1 - ql11; plc12 = qlbar2 - ql12; plc13 = qlbar3 - ql13;
        plc21 = qlbar1 - ql21; plc22 = qlbar2 - ql22; plc23 = qlbar3 - ql23;
        plc31 = qlbar1 - ql31; plc32 = qlbar2 - ql32; plc33 = qlbar3 - ql33;
        
        HS = [pc11*plc11+pc21*plc21+pc31*plc31, pc11*plc12+pc21*plc22+pc31*plc32, pc11*plc13+pc21*plc23+pc31*plc33;...
              pc12*plc11+pc22*plc21+pc32*plc31, pc12*plc12+pc22*plc22+pc32*plc32, pc12*plc13+pc22*plc23+pc32*plc33;...
              pc13*plc11+pc23*plc21+pc33*plc31, pc13*plc12+pc23*plc22+pc33*plc32, pc13*plc13+pc23*plc23+pc33*plc33];
        
        [U,~,V] = svd(HS);
        
        v11 = V(1,1); v12 = V(1,2); v13 = V(1,3);
        v21 = V(2,1); v22 = V(2,2); v23 = V(2,3);
        v31 = V(3,1); v32 = V(3,2); v33 = V(3,3);
        u11 = U(1,1); u12 = U(1,2); u13 = U(1,3);
        u21 = U(2,1); u22 = U(2,2); u23 = U(2,3);
        u31 = U(3,1); u32 = U(3,2); u33 = U(3,3);
        
        detVU = u11*u22*u33*v11*v22*v33 - u11*u22*u33*v11*v23*v32 - u11*u22*u33*v12*v21*v33 + u11*u22*u33*v12*v23*v31 + u11*u22*u33*v13*v21*v32 - u11*u22*u33*v13*v22*v31 - u11*u23*u32*v11*v22*v33 + u11*u23*u32*v11*v23*v32 + u11*u23*u32*v12*v21*v33 - u11*u23*u32*v12*v23*v31 - u11*u23*u32*v13*v21*v32 + u11*u23*u32*v13*v22*v31 - u12*u21*u33*v11*v22*v33 + u12*u21*u33*v11*v23*v32 + u12*u21*u33*v12*v21*v33 - u12*u21*u33*v12*v23*v31 - u12*u21*u33*v13*v21*v32 + u12*u21*u33*v13*v22*v31 + u12*u23*u31*v11*v22*v33 - u12*u23*u31*v11*v23*v32 - u12*u23*u31*v12*v21*v33 + u12*u23*u31*v12*v23*v31 + u12*u23*u31*v13*v21*v32 - u12*u23*u31*v13*v22*v31 + u13*u21*u32*v11*v22*v33 - u13*u21*u32*v11*v23*v32 - u13*u21*u32*v12*v21*v33 + u13*u21*u32*v12*v23*v31 + u13*u21*u32*v13*v21*v32 - u13*u21*u32*v13*v22*v31 - u13*u22*u31*v11*v22*v33 + u13*u22*u31*v11*v23*v32 + u13*u22*u31*v12*v21*v33 - u13*u22*u31*v12*v23*v31 - u13*u22*u31*v13*v21*v32 + u13*u22*u31*v13*v22*v31;
        sdetVU = sign(detVU);
        
        rr11 = v11; rr12 = v12; rr13 = sdetVU*v13;
        rr21 = v21; rr22 = v22; rr23 = sdetVU*v23;
        rr31 = v31; rr32 = v32; rr33 = sdetVU*v33;
        
        r11 = rr11*u11 + rr12*u12 + rr13*u13;r12 = rr11*u21 + rr12*u22 + rr13*u23;r13 = rr11*u31 + rr12*u32 + rr13*u33;
        r21 = rr21*u11 + rr22*u12 + rr23*u13;r22 = rr21*u21 + rr22*u22 + rr23*u23;r23 = rr21*u31 + rr22*u32 + rr23*u33;
        r31 = rr31*u11 + rr32*u12 + rr33*u13;r32 = rr31*u21 + rr32*u22 + rr33*u23;r33 = rr31*u31 + rr32*u32 + rr33*u33;
        
        t1 = qlbar1 - r11*qbar1 - r12*qbar2 - r13*qbar3;
        t2 = qlbar2 - r21*qbar1 - r22*qbar2 - r23*qbar3;
        t3 = qlbar3 - r31*qbar1 - r32*qbar2 - r33*qbar3;
        
        R = [r11,r12,r13;r21,r22,r23;r31,r32,r33];
        T = [t1;t2;t3];
        
        Rs(:,((i-1)*3+1):i*3) = R;
        Ts(:,i) = T;
        
    end
    
    if ~isempty(Ts), NumSol = numel(Ts(1,:)); end
    
else
%     disp('falhou...')
    NumSol = [];
    Ts = [];
    Rs = [];
end

Time_ALL = toc(tic_time_ALL);

end

