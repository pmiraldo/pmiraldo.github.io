General
Complete name                    : VIDEO_iccv2011_calib_generic_model.mp4
Format                           : MPEG-4
Format profile                   : Base Media / Version 2
Codec ID                         : mp42
File size                        : 24.7 MiB
Duration                         : 3mn 35s
Overall bit rate                 : 960 Kbps
Encoded date                     : UTC 2011-03-04 15:55:54
Tagged date                      : UTC 2011-03-04 15:55:54
                                 : 00:00:00:07

Video
ID                               : 1
Format                           : AVC
Format/Info                      : Advanced Video Codec
WEBSITE	                         : http://www.h264encoder.com/
Format profile                   : High@L5.1
Format settings, CABAC           : Yes
Format settings, ReFrames        : 3 frames
Codec ID                         : avc1
Codec ID/Info                    : Advanced Video Coding
Duration                         : 3mn 35s
Bit rate mode                    : Variable
Bit rate                         : 955 Kbps
Width                            : 1 500 pixels
Height                           : 900 pixels
Display aspect ratio             : 1.667
Frame rate mode                  : Constant
Frame rate                       : 25.000 fps
Standard                         : PAL
Color space                      : YUV
Chroma subsampling               : 4:2:0
Bit depth                        : 8 bits
Scan type                        : Progressive
Bits/(Pixel*Frame)               : 0.028
Stream size                      : 24.6 MiB (100%)
Language                         : English
Encoded date                     : UTC 2011-03-04 15:55:54
Tagged date                      : UTC 2011-03-04 15:55:54
Color primaries                  : BT.709-5, BT.1361, IEC 61966-2-4, SMPTE RP177
Transfer characteristics         : BT.709-5, BT.1361
Matrix coefficients              : BT.709-5, BT.1361, IEC 61966-2-4 709, SMPTE RP177
