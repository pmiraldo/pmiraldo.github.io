% Pedro Miraldo <pedro.miraldo@tecnico.ulisboa.pt>
% Jose Iglesias <jose.iglesias@chalmers.se>
% MATLAB R2020b/R2021a

close all
warning off

if ispc
    addpath('AgrawalForwardProjectionToolBox\OffAxisCatadioptric')
    addpath('AgrawalForwardProjectionToolBox\AxialCatadioptric')
    addpath('helper\export_fig')
    addpath('helper\')
else
    addpath('AgrawalForwardProjectionToolBox/OffAxisCatadioptric')
    addpath('AgrawalForwardProjectionToolBox/AxialCatadioptric')
    addpath('helper/export_fig')
    addpath('helper/')
end

%% colors

blue = [0 0.4470 0.7410];	
orange = [0.8500 0.3250 0.0980];
yellow = [0.9290 0.6940 0.1250];
magenta = [0.4940 0.1840 0.5560];
green = [0.4660 0.6740 0.1880];
cyan = [0.3010 0.7450 0.9330];
red = [0.6350 0.0780 0.1840];

%% Mirror Parameters
k = 7;
c_3 = 35;
t = [0;0;c_3];

% projection parameters H
K = [750, 0, 600;
    0, 750, 400;
    0, 0, 1];
R = angle2dcm(0,0,pi);

A = -2/(k - 2);
B = (2*c_3)/(k - 2);
C = (c_3^2*(k/(k - 2) - 1))/(2*k);

disp(['Mirror Parameters (A, B, C) = (', num2str(A), ', ', num2str(B), ', ', num2str(C) ')'])
disp(['Camera position (c_2, c_3) = (', num2str(t(2)), ', ', num2str(t(3)), ')'])

% C0 = x^2 + y^2 + A*z^2 + B*z - C;
t1 = t(1); t2 = t(2); t3 = t(3);

%% Line parameters
d = [3;-1;10];
l = [1;1;-5];
d = d/norm(d);
p = [-10;-40;-10];
d1 = d(1); d2 = d(2); d3 = d(3);
p1 = p(1); p2 = p(2); p3 = p(3);

point_agrawal.l1 = [0;0;0];
point_agrawal.l2 = [0;0;0];

%% Plot 3D mirror
zmin = -25;
zmax = 10;
xymax = 50;

plot_mirror(A,B,C,xymax,zmin,zmax,0.5)
hold all;
text(t1,t2,t3+7.5,'Camera','HorizontalAlignment','right','FontSize',8);
scatter3(t1,t2,t3,25,'ko','filled');
quiver3(t1,t2,t3,R(1,3),R(2,3),R(3,3),10,'color',red,'linewidth',2)
quiver3(t1,t2,t3,R(1,2),R(2,2),R(3,2),10,'color',green,'linewidth',2)
quiver3(t1,t2,t3,R(1,1),R(2,1),R(3,1),10,'color',blue,'linewidth',2)

for line_iter = 1 : 2

    if line_iter == 1
        line_color = blue;
        d1 = d(1); d2 = d(2); d3 = d(3);
        p1 = p(1); p2 = p(2); p3 = p(3);
    end
    if line_iter == 2
        line_color = red;
        d1 = l(1); d2 = l(2); d3 = l(3);
        p1 = p(1); p2 = p(2); p3 = p(3);
    end

    plot3([p1+1000*d1;p1-1000*d1],[p2+1000*d2;p2-1000*d2],[p3+1000*d3;p3-1000*d3], 'Color', line_color, 'LineWidth',2);

    % parameters needed for getting the line in the image
    c_2 = t2; c_3 = t3;
    q_1 = p1; q_2 = p2; q_3 = p3;
    s_1 = d1; s_2 = d2; s_3 = d3;

    y_ = -50:.1:50;
    for y = y_

        cc1 = k*(2*q_1^2*s_2^2 + 2*q_2^2*s_1^2 + 2*q_2^2*s_3^2 + 2*q_3^2*s_2^2 - k*q_1^2*s_2^2 - k*q_2^2*s_1^2 - 4*q_1*q_2*s_1*s_2 - 4*q_2*q_3*s_2*s_3 + 2*k*q_1*q_2*s_1*s_2);
        cc2 = 2*k*(q_2*s_3 - q_3*s_2)*(c_3*q_1*s_2 - c_3*q_2*s_1 - 2*q_1*s_3*y + 2*q_3*s_1*y);
        cc3 = c_3^2*q_1^2*s_2^2 - 2*c_3^2*q_1*q_2*s_1*s_2 + c_3^2*q_2^2*s_1^2 - 2*c_3*k*q_1^2*s_2*s_3*y + 2*c_3*k*q_1*q_2*s_1*s_3*y + 2*c_3*k*q_1*q_3*s_1*s_2*y - 2*c_3*k*q_2*q_3*s_1^2*y - k^2*q_1^2*s_2^2*y^2 + 2*k^2*q_1*q_2*s_1*s_2*y^2 - k^2*q_2^2*s_1^2*y^2 + 2*k*q_1^2*s_2^2*y^2 + 2*k*q_1^2*s_3^2*y^2 - 4*k*q_1*q_2*s_1*s_2*y^2 - 4*k*q_1*q_3*s_1*s_3*y^2 + 2*k*q_2^2*s_1^2*y^2 + 2*k*q_3^2*s_1^2*y^2;
        pol = [cc1 cc2 cc3];

        x_ = roots(pol);
        x_(imag(x_) ~= 0) = [];
        if isempty(x_)
            continue;
        end

        for iter = 1: numel(x_)
            x = x_(iter);

            % first guess for z
            z1 = -(B - (B^2 - 4*A*x^2 - 4*A*y^2 + 4*A*C)^(1/2))/(2*A);
            r = [x;y;z1];
            vi = r - t;
            n = [x;y;B/2 + A*z1]; n = n/norm(n);
            vr = vi - 2*(vi'*n)*n; vr = vr/norm(vr);
            dist1 = line_to_line_distance(r, vr, [p1, p2, p3]', [d1, d2, d3]',0);
            
            % second guess for z
            z2 = -(B + (B^2 - 4*A*x^2 - 4*A*y^2 + 4*A*C)^(1/2))/(2*A);
            r = [x;y;z2];
            vi = r - t;
            n = [x;y;B/2 + A*z2]; n = n/norm(n);
            vr = vi - 2*(vi'*n)*n; vr = vr/norm(vr);
            dist2 = line_to_line_distance(r, vr, [p1, p2, p3]', [d1, d2, d3]',0);
            
            if abs(dist1) < .1 && z1 < zmax && z1 > zmin
                plot3(x,y,z1,'o','Color', line_color, 'MarkerSize',1);
            end
            if abs(dist2) < .1  && z2 < zmax && z2 > zmin
                plot3(x,y,z2,'o','Color', line_color, 'MarkerSize',1);
            end
        end

    end

    iter_agrawal = 1;
    for iter = -25:5:25
        px = p1 + iter*d1;
        py = p2 + iter*d2;
        pz = p3 + iter*d3;

        solMirrorPoint_array = ComputeForwardProjectionAxial(t,[px;py;pz],A,B,C,50);

        for iiter = 1:numel(solMirrorPoint_array(1,:))
            solMirrorPoint = solMirrorPoint_array(:,iiter);
            if norm(solMirrorPoint) ~= 0
                z = solMirrorPoint(3);
                if line_iter == 1
                    point_agrawal.l1(:,iter_agrawal) = solMirrorPoint;
                    iter_agrawal = iter_agrawal + 1;
                end
                if line_iter == 2 
                    point_agrawal.l2(:,iter_agrawal) = solMirrorPoint;
                    iter_agrawal = iter_agrawal + 1;
                end
            end
        end

    end

end


axis equal;
view(-76,65)
grid off
set(gca,'visible','off')
box on
axis([-50,50,-50,50,-35,50]);
hold off

export_fig('central_hyperboloidal_world', '-jpg', '-transparent', '-zbuffer','-r600');



%% plot image

k1_1 = K(1,1); k1_3 = K(1,3);
k2_2 = K(2,2); k2_3 = K(2,3);
r1_1 = R(1,1); r1_2 = R(1,2); r1_3 = R(1,3);
r2_1 = R(2,1); r2_2 = R(2,2); r2_3 = R(2,3);
r3_1 = R(3,1); r3_2 = R(3,2); r3_3 = R(3,3);

h1_1 = k1_1*r1_1 + k1_3*r3_1;
h1_2 =  k1_1*r1_2 + k1_3*r3_2;
h1_3 = k1_1*r1_3 + k1_3*r3_3;
h2_1 = k2_2*r2_1 + k2_3*r3_1;
h2_2 = k2_2*r2_2 + k2_3*r3_2;
h2_3 = k2_2*r2_3 + k2_3*r3_3;
h3_1 = r3_1;
h3_2 = r3_2;
h3_3 = r3_3;

figure(2)
hold all;
v_ = 0:1:1200;

for line_iter = 1:2

    if line_iter == 1
        line_color = blue;
        p = [-10;-40;-10];
        d1 = d(1); d2 = d(2); d3 = d(3);
        p1 = p(1); p2 = p(2); p3 = p(3);
    end
    if line_iter == 2
        line_color = red;
        p = [-10;-40;-10];
        d1 = l(1); d2 = l(2); d3 = l(3);
        p1 = p(1); p2 = p(2); p3 = p(3);
    end
    
    c_2 = t2; c_3 = t3;
    q_1 = p1; q_2 = p2; q_3 = p3;
    s_1 = d1; s_2 = d2; s_3 = d3;
    
    % computing projection curve coeficients
    script_pol_uv_central_hyperboloidal


    for iitem = 1 : numel(v_)

        vi = v_(iitem);

        % computing coeficients for ploting
        script_pol_ui_central_hyperboloidal
        
        pol = [c_ui1 c_ui2 c_ui3];
        pol = pol/pol(1);

        u_ = roots(pol);
        u_(imag(u_) ~= 0) = [];
        if isempty(u_)
            continue;
        end
        for item = 1 : numel(u_)
            i = [u_(item);vi;1];
            i = i/i(3);
            plot(i(1),i(2),'o','Color', line_color,'MarkerSize',2, 'LineWidth', 2);
        end

    end

    if line_iter == 1
        num_points = numel(point_agrawal.l1(1,:));
    end
    if line_iter == 2
        num_points = numel(point_agrawal.l2(1,:));
    end
        
    for iiter = 1 : num_points

        if line_iter == 1
            point3d = point_agrawal.l1(:,iiter);
        end
        if line_iter == 2
            point3d = point_agrawal.l2(:,iiter);
        end
        i = K*R*(point3d - [t1;t2;t3]);
        i = i/i(3);
        plot(i(1),i(2),'+', 'Color', green, 'MarkerSize',9, 'LineWidth', 1);

    end
end

box on
set(gca, 'YDir','reverse')
axis('equal')
axis([0,K(1,3)*2,0,K(2,3)*2])
% xlabel('---u---')
% ylabel('---v---')
set(gca,'FontSize',15)
hold off

export_fig('central_hyperboloidal_image.jpg', '-jpg', '-transparent', '-zbuffer','-r600');


if ispc
    rmpath('AgrawalForwardProjectionToolBox\AxialCatadioptric\')
    rmpath('AgrawalForwardProjectionToolBox\OffAxisCatadioptric\')
    rmpath('helper\export_fig')
    rmpath('helper\')
else
    rmpath('AgrawalForwardProjectionToolBox/AxialCatadioptric/')
    rmpath('AgrawalForwardProjectionToolBox/OffAxisCatadioptric/')
    rmpath('helper/export_fig')
    rmpath('helper/')
end


