% Pedro Miraldo <pedro.miraldo@tecnico.ulisboa.pt>
% Jose Iglesias <jose.iglesias@chalmers.se>
% MATLAB R2020b/R2021a

c_ui1 = c_uv6*cd1^2 + c_uv1*cnu1^2 + c_uv4*cnv1^2 + c_uv3*cd1*cnu1 + c_uv5*cd1*cnv1 + c_uv2*cnu1*cnv1;
c_ui2 = 2*c_uv6*cd1*cd3 + c_uv3*cd1*cnu3 + c_uv3*cd3*cnu1 + c_uv5*cd1*cnv3 + c_uv5*cd3*cnv1 + 2*c_uv1*cnu1*cnu3 + c_uv2*cnu1*cnv3 + c_uv2*cnu3*cnv1 + 2*c_uv4*cnv1*cnv3 + c_uv3*cd1*cnu2*vi + c_uv3*cd2*cnu1*vi + c_uv5*cd1*cnv2*vi + c_uv5*cd2*cnv1*vi + 2*c_uv1*cnu1*cnu2*vi + c_uv2*cnu1*cnv2*vi + c_uv2*cnu2*cnv1*vi + 2*c_uv4*cnv1*cnv2*vi + 2*c_uv6*cd1*cd2*vi;
c_ui3 = c_uv6*cd3^2 + c_uv1*cnu3^2 + c_uv4*cnv3^2 + c_uv6*cd2^2*vi^2 + c_uv1*cnu2^2*vi^2 + c_uv4*cnv2^2*vi^2 + c_uv3*cd3*cnu3 + c_uv5*cd3*cnv3 + c_uv2*cnu3*cnv3 + c_uv3*cd2*cnu3*vi + c_uv3*cd3*cnu2*vi + c_uv5*cd2*cnv3*vi + c_uv5*cd3*cnv2*vi + 2*c_uv1*cnu2*cnu3*vi + c_uv2*cnu2*cnv3*vi + c_uv2*cnu3*cnv2*vi + 2*c_uv4*cnv2*cnv3*vi + c_uv3*cd2*cnu2*vi^2 + c_uv5*cd2*cnv2*vi^2 + c_uv2*cnu2*cnv2*vi^2 + 2*c_uv6*cd2*cd3*vi;
