% Pedro Miraldo <pedro.miraldo@tecnico.ulisboa.pt>
% Jose Iglesias <jose.iglesias@chalmers.se>
% MATLAB R2020b/R2021a

c_uv1 = k^2*q_1^2*s_2^2 - q_3^2*s_2^2 - 2*k*q_1^2*s_2^2 - 2*k*q_2^2*s_1^2 - q_2^2*s_3^2 + k^2*q_2^2*s_1^2 + 2*q_2*q_3*s_2*s_3 + 4*k*q_1*q_2*s_1*s_2 - 2*k^2*q_1*q_2*s_1*s_2;
c_uv2 = 2*(q_1*s_3 - q_3*s_1)*(q_2*s_3 - q_3*s_2);
c_uv3 = 2*(k - 1)*(q_1*s_2 - q_2*s_1)*(q_2*s_3 - q_3*s_2);
c_uv4 = k^2*q_1^2*s_2^2 - q_3^2*s_1^2 - 2*k*q_1^2*s_2^2 - 2*k*q_2^2*s_1^2 - q_1^2*s_3^2 + k^2*q_2^2*s_1^2 + 2*q_1*q_3*s_1*s_3 + 4*k*q_1*q_2*s_1*s_2 - 2*k^2*q_1*q_2*s_1*s_2;
c_uv5 = -2*(k - 1)*(q_1*s_2 - q_2*s_1)*(q_1*s_3 - q_3*s_1);
c_uv6 = -(q_1*s_2 - q_2*s_1)^2;

cnu1 = h2_2*h3_3 - h2_3*h3_2;
cnu2 = h1_3*h3_2 - h1_2*h3_3;
cnu3 = h1_2*h2_3 - h1_3*h2_2;
cnv1 = h2_3*h3_1 - h2_1*h3_3;
cnv2 = h1_1*h3_3 - h1_3*h3_1;
cnv3 = h1_3*h2_1 - h1_1*h2_3;
cd1 = h2_1*h3_2 - h2_2*h3_1;
cd2 = h1_2*h3_1 - h1_1*h3_2;
cd3 = h1_1*h2_2 - h1_2*h2_1;